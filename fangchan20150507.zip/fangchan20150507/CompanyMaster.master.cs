﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CompanyMaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
         Labeldate.Text = DateTime.Now.ToLongDateString().ToString();
        Labeltime.Text = DateTime.Now.ToShortTimeString().ToString();
        Labeldayofweek.Text = DateTime.Now.DayOfWeek.ToString();
        //在load事件里调用GetWeekDay()

        Labeldayofweek.Text = this.GetWeekDay();
    }

    //自定义函数GetWeekDay()
    private string GetWeekDay()
    {
        string Temp = "";
        switch (DateTime.Now.DayOfWeek)
        {
            case DayOfWeek.Sunday:
                Temp = "星期日"; break;
            case DayOfWeek.Monday:
                Temp = "星期一"; break;
            case DayOfWeek.Tuesday:
                Temp = "星期二"; break;
            case DayOfWeek.Wednesday:
                Temp = "星期三"; break;
            case DayOfWeek.Thursday:
                Temp = "星期四"; break;
            case DayOfWeek.Friday:
                Temp = "星期五"; break;
            case DayOfWeek.Saturday:
                Temp = "星期六"; break;
        } return Temp;
    }
    }
