﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Housecondpublish : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox4.Text = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString();
        if (!IsPostBack)
        {
            Bind();
            if (Session["perid"] != null)
            {

            }
            else
            {
                Response.Write("<script>alert('请登录再查找信息，谢谢！');location.href = 'index.aspx';</script>");
                return;
            }
        }

    }
    private void Bind()//初始化
    {
        SqlConnection sqlcon = new SqlConnection("server=.;database=TFang;uid=sa;pwd=sa;");
        sqlcon.Open();
        SqlCommand sqlcmdpro = new SqlCommand("select * from quyu", sqlcon);
        SqlDataReader sdrpro = sqlcmdpro.ExecuteReader();
        this.ddlzone.DataSource = sdrpro;
        this.ddlzone.DataTextField = "p_name";//显示的值
        this.ddlzone.DataValueField = "p_name";//主键
        this.ddlzone.DataBind();
        sdrpro.Close();
        sqlcon.Close();
    }
    
    protected void btn_send_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            string filename = FileUpload1.FileName.ToString();
            if (filename.Contains("jpg") || filename.Contains("png"))
            {
                FileUpload1.SaveAs(Server.MapPath("~/Image/housecond/" + TextBox4.Text + ".png"));//上传文件至某一路径下
                String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
                SqlConnection myConnection = new SqlConnection(myconn);
                myConnection.Open();
                string stradd = "insert into housecond(username,txthousename,ISBN,ddlsort,ddlzone,txtaddress,txtacreage,ddlfitment,ddlhouseright,builddate,ddltype,memtype,sellprice,txtwuye,txtWuyeaddress,head,txtCeng,txtCeng2,txtJiaotong,txtXuexiao,txtYiyuan,txtYinhang,txtTingche,context,linkpeople,phone,email) values('" + Session["username"] + "','" + txthousename.Text + "','" + TextBox4.Text + "','" + ddlsort.Text + "', '" + this.ddlzone.SelectedValue.ToString() + "','" + txtaddress.Text + "','" + txtacreage.Text + "','" + ddlfitment.Text + "','" + ddlhouseright.Text + "','" + builddate.Text + "','" + ddltype.Text + "','" + memtype.Text + "','" + sellprice.Text + "','" + txtwuye.Text + "','" + txtWuyeaddress.Text + "','" + head.Text + "','" + txtCeng.Text + "','" + txtCeng2.Text + "','" + txtJiaotong.Text + "','" + txtXuexiao.Text + "','" + txtYiyuan.Text + "','" + txtYinhang.Text + "','" + txtTingche.Text + "','" + context.Text + "','" + linkpeople.Text + "','" + phone.Text + "','" + email.Text + "')";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = myConnection;
                cmd.CommandText = stradd;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                myConnection.Close();
                Common.Alert("发布成功!", this);
            }
            else
            { Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "r", "alert(\" 请上传jpg，png格式的商品图片！\")", true); }
            }
        else
        { Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "s", "alert(\"请上传商品图片！\")", true); }
    }
}











