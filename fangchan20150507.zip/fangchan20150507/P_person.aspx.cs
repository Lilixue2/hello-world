﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ts_p_person : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["perid"] != null)
            {
                InitInformation();
            }
            else
            {
                Response.Redirect("index.aspx");
                return;
            }

        }
    }

    private void InitInformation()
    {
        String pername = Session["username"].ToString();
        String sql = String.Empty; 
        sql = "SELECT UserName FROM personal_base  where username=@0;";
        sql += "SELECT COUNT(pername) Id FROM favorites WHERE pername=@0;";
        sql += "SELECT COUNT(pername) Id FROM favoritesecond WHERE pername=@0;";
        DataSet person = DB.GetDataSet(sql,pername);
        if (person.Tables.Count > 0)
        {
            lblUserName.Text = person.Tables[0].Rows[0]["UserName"].ToString();
            lblFavorate.Text = person.Tables[1].Rows[0]["Id"].ToString();
            lblFavorate2.Text = person.Tables[2].Rows[0]["Id"].ToString();

        }

    }
}

