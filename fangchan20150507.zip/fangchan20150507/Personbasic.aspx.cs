﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class ts_personbasic : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["perid"] != null)
            {
                loadBaseInfo();
            }
            else
            {
                Response.Write("<script>alert('请登录再查找信息，谢谢！');location.href = 'index.aspx';</script>");
                return;
            }
        }
    }

    private void loadBaseInfo()
    {
        String perid = Session["perid"].ToString();
        txtPerid.Value = perid;
        String sql = "SELECT phone,Email FROM personal_base WHERE perid = @0";
        DataTable user = DB.GetDataSet(sql, perid).Tables[0];
        if (user.Rows.Count > 0)
        {
            txtMobile.Text = user.Rows[0]["phone"].ToString();
            txtMail.Text = user.Rows[0]["Email"].ToString();
        }

    }

    protected void btnOk_Click(object sender, EventArgs e)
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection strcon = new SqlConnection(myconn);
        strcon.Open();
        string stradd = "update personal_base set phone='" + txtMobile.Text + "',Email='" + txtMail.Text + "',Question='" + txtQuestion.Text + "',Answer= '" + txtAnswer.Text + "' where  username = '" + Session["username"] + "'";
        SqlCommand mycmd = new SqlCommand();
        mycmd.Connection = strcon;
        mycmd.CommandText = stradd;
        mycmd.CommandType = CommandType.Text;
        mycmd.ExecuteNonQuery();
        strcon.Close();
        Common.Alert("保存数据成功!", this);
        loadBaseInfo();
    }
}
