﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ts_Companyinfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            loadBaseInfo(Request.QueryString["comid"].ToString());
        }
    }

    private void loadBaseInfo(String comid)
    {
        //*防止SQL注入
        //if (!DB.CheckParams(new object[] { comid }))
        //{
        //    Response.Redirect("ErrorSQLZR.aspx");
        //    return;
        //}

        txtComId.Value = comid;

        String sql = "SELECT * FROM company_base WHERE comid = @0";
        DataTable company = DB.GetDataSet(sql, comid).Tables[0];

        if (company.Rows.Count > 0)
        {
            DataRow row = company.Rows[0];

            lblCompany.Text = Convert.ToString(row["companyname"]);
            lblLicense.Text = Convert.ToString(row["license"]);
            lblWorkers.Text = Convert.ToString(row["workers"]);
            lblEmail.Text = Convert.ToString(row["email"]);
            lblWebsite.Text = Convert.ToString(row["website"]);
            lblAddress.Text = Convert.ToString(row["address"]);

            if (Convert.ToString(row["Logo"]) != null && Convert.ToString(row["Logo"]) != "")
            {
                string path = "image/uploadfile/";
                imgLogo.ImageUrl = path + Convert.ToString(row["Logo"]).Trim();
            }
            else
            {
                imgLogo.ImageUrl = "image/Company.gif";
            }
        }
    }

}

