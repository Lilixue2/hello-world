﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ts_changepwd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["comid"] != null)
        {
        }
        else
        {
            Response.Write("<script>alert('请登录再查找信息，谢谢！');location.href = 'index.aspx';</script>");
            return;
        }
    }



    protected void btnOK_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["comid"] != null)
            {
                ArrayList paramList = new ArrayList();
                String comid = Session["comid"].ToString();

                String sql = "SELECT password FROM company_base WHERE comid=@0";
                DataTable user = DB.GetDataSet(sql, comid).Tables[0];
                if (user.Rows.Count > 0)
                {
                    if (user.Rows[0]["password"].ToString() == Common.Md5(txtOldUserPwd.Text))
                    {
                        sql = "UPDATE company_base SET password=@0 WHERE comid=@1";

                        paramList.Clear();
                        paramList.Add(Common.Md5(txtUserPwd.Text));
                        paramList.Add(comid);
                        DB.ExecuteSQL(sql, paramList);

                        txtOldUserPwd.Text = "";
                        txtUserPwd.Text = "";
                        txtConfirmUserPwd.Text = "";
                        lblTips.Text = "更改密码成功";


                    }
                    else
                    {
                        lblTips.Text = "原密码错误!";
                    }
                }
            }
            else
            {
                Response.Redirect("Company.aspx?mode=0");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            Response.End();
        }
    }

}
