﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class flfg : System.Web.UI.Page
{
    private Bill bl = new Bill();
    protected void Page_Load(object sender, EventArgs e)
    {
        this.DataList2.DataSource = this.bl.GetNewW();
        this.DataList2.DataBind();


        LoadData();



    }


    private bool getnum(string num)
    {
        try
        {
            Convert.ToInt32(num);
            return true;
        }
        catch
        {
            return false;
        }
    }



    public void LoadData()
    {
        try
        {

            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn);
            myConnection.Open();
            string strSql = "SELECT  NewsID, Title, Author,content, AddDate FROM news_info WHERE IsActive = 1 AND IsVerified = 1 AND TypeID = 4 ORDER BY newsid DESC";
            SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
            DataSet ds = new DataSet();
            adapt.Fill(ds, "news_info");
            this.lstRecruit.DataSource = ds.Tables["news_info"];
            lstRecruit.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            Response.End();
        }
    }

    protected string Left(object s, int length)
    {
        try
        {
            string ret;

            if (s.ToString().Trim() == "")
                return "---";
            if (s.ToString().Length > length)
            {
                ret = s.ToString();
                ret = ret.Substring(0, length) + "...";
            }
            else
            {
                return s.ToString();
            }
            return ret;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}

