﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Housecondmanage : System.Web.UI.Page
{
    SqlConnection sqlcon;
    SqlCommand sqlcom;
    string strCon = "Data Source=(local);Database=TFang;Uid=sa;Pwd=sa";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            bind();
            loadData();
            if (Session["perid"] != null)
            {
            }
            else
            {
                Response.Write("<script>alert('请登录再查找信息，谢谢！');location.href = 'index.aspx';</script>");
            }
        }

    }
    private void loadData()
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();
        string strSql = "select * from housecond where username = '" + Session["username"] + "'";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
        DataSet ds = new DataSet();
        adapt.Fill(ds, "housecond");
        this.GridView1.DataSource = ds.Tables["housecond"];
        this.GridView1.DataKeyNames = new string[] { "housecondid" };
        GridView1.DataBind();
    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        bind();
    }

    //删除
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string sqlstr = "delete from housecond where housecondid='" + GridView1.DataKeys[e.RowIndex].Value.ToString() + "' and username = '" + Session["username"] + "'";
        sqlcon = new SqlConnection(strCon);
        sqlcom = new SqlCommand(sqlstr, sqlcon);
        sqlcon.Open();
        sqlcom.ExecuteNonQuery();
        sqlcon.Close();
        bind();
        Response.Write("<script>alert('信息删除成功！');</script>");
    }

    //更新
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        sqlcon = new SqlConnection(strCon);
        string sqlstr = "update housecond set txthousename='"
            + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[0].Controls[0])).Text.ToString().Trim() + "',ddlzone='"
            + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[1].Controls[0])).Text.ToString().Trim() + "', head='"
            + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[2].Controls[0])).Text.ToString().Trim() + "' ,linkpeople='"
            + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[3].Controls[0])).Text.ToString().Trim() + "',phone='"
            + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[4].Controls[0])).Text.ToString().Trim() + "', txtaddress='"
            + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[5].Controls[0])).Text.ToString().Trim() + "' where housecondid='"
            + GridView1.DataKeys[e.RowIndex].Value.ToString() + "' and username = '" + Session["username"] + "'";
        sqlcom = new SqlCommand(sqlstr, sqlcon);
        sqlcon.Open();
        sqlcom.ExecuteNonQuery();
        sqlcon.Close();
        GridView1.EditIndex = -1;
        bind();
    }

    //取消
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        bind();
    }

    //绑定
    public void bind()
    {
        string sqlstr = "select * from housecond where username = '" + Session["username"] + "'";
        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "housecond");
        GridView1.DataSource = myds;
        GridView1.DataKeyNames = new string[] { "housecondid" };//主键
        GridView1.DataBind();
        sqlcon.Close();
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //如果是绑定数据行 
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate)
            {
                ((LinkButton)e.Row.Cells[7].Controls[0]).Attributes.Add("onclick", "javascript:return confirm('你确认要删除：\"" + e.Row.Cells[0].Text + "\"吗?')");
            }
        }

    }
    

    protected void Houname_Click(object sender, EventArgs e)
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();

        string strqq = txthousename.Text.Trim();
        string strSql = "select * from housecond where txthousename='" + strqq + "' and username = '" + Session["username"] + "'";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);

        DataSet ds = new DataSet();
        adapt.Fill(ds, "housecond");

        this.GridView1.DataSource = ds.Tables["housecond"];
        GridView1.DataBind();
    }

    protected void Houquyu_Click(object sender, EventArgs e)
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();

        string strqq = ddlzone.Text.Trim();
        string strSql = "select * from housecond where ddlzone='" + strqq + "' and username = '" + Session["username"] + "'";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);

        DataSet ds = new DataSet();
        adapt.Fill(ds, "housecond");
        this.GridView1.DataSource = ds.Tables["housecond"];
        GridView1.DataBind();
    
}
}