﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Housecond_view : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            string housecondid = Request["housecondid"];
            Session["housecondid"] = housecondid;

            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn);
            myConnection.Open();
            string strSql = "select * from housecond where housecondid='" + housecondid + "' ";
            SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
            DataSet ds = new DataSet();
            adapt.Fill(ds, "housecond");
            this.DataList1.DataSource = ds.Tables["housecond"];
            DataList1.DataBind();


        }

    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
    }

    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void ImageButton_Click(object sender, EventArgs e)
    {
        if (Session["perid"] != null)
        {
            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection strcon = new SqlConnection(myconn);
            strcon.Open();
            SqlCommand scd1 = new SqlCommand("insert into favoritesecond(faname,Pername,housecondid,AddDate)values('" + Session["username"] + "','" + Session["username"] + "','" + Session["housecondid"] + "', '" + DateTime.Now.ToString() + "')", strcon);
            scd1.ExecuteNonQuery();
            strcon.Close();
            Common.Alert("收藏成功!", this);


        }
        else
        {
            Response.Write("<script>alert('请登录再收藏信息，谢谢！');location.href = 'index.aspx';</script>");
            return;
        }
     }
}