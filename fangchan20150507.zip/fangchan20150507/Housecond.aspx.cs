﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class housecond : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn);
            myConnection.Open();
            string strSql = "select  Top(16) * from housecond order by housecondid desc ";
            SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
            DataSet ds = new DataSet();
            adapt.Fill(ds, "housecond");
            this.DataList1.DataSource = ds.Tables["housecond"];
            DataList1.DataBind();
        }

    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        string housecondid = ((Label)e.Item.FindControl("Label2")).Text;

        if (e.CommandName == "ImageButton")
        {
            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn);
            myConnection.Open();
            string strsql = "select * from housecond where housecondid='" + housecondid + "'";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = myConnection;
            cmd.CommandText = strsql;
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            myConnection.Close();
            Response.Redirect(string.Format("~/Housecond_view.aspx?housecondid={0}", housecondid));

        }
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}