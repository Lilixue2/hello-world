﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class housenew : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn);
            myConnection.Open();
            string strSql = "select  Top(16) * from house order by houseid desc ";
            SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
            DataSet ds = new DataSet();
            adapt.Fill(ds, "house");
            this.DataList1.DataSource = ds.Tables["house"];
            DataList1.DataBind();
        }

    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        string houseid = ((Label)e.Item.FindControl("Label2")).Text;

        if (e.CommandName == "ImageButton")
        {
            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn);
            myConnection.Open();
            string strsql = "select * from house where houseid='" + houseid + "'";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = myConnection;
            cmd.CommandText = strsql;
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            myConnection.Close();
            Response.Redirect(string.Format("~/Housenew_view.aspx?houseid={0}", houseid));
           
        }
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    }