﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ts_Company : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["comid"] != null)
            {
                InitInformation();
                saveLoginInfo();
            }
            else
            {
                Response.Write("<script>alert('请登录再查找信息，谢谢！');location.href = 'index.aspx';</script>");
                return;
            }

        }
    }

    private void InitInformation()
    {
        String comid = Session["comid"].ToString();
        String sql = String.Empty;
        sql = "SELECT username,companyname FROM company_base WHERE comid=@0;";
        sql += "SELECT COUNT(houseid) housecnt FROM house WHERE username=@0;";
    }


    private void saveLoginInfo()
    {
        String comid = Session["comid"].ToString();
        ArrayList paramList = new ArrayList();
        paramList.Add(Request.ServerVariables.Get("REMOTE_ADDR").ToString());
        paramList.Add(comid);

    }
}

