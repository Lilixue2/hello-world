﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String userName = Request.Form["txtUserName"].ToString();
        String userPwd = Request.Form["txtUserPwd"].ToString();
        String userType = Request.Form["cmbLoginType"].ToString();

        //*防止SQL注入
        //if (!DB.CheckParams(new object[] { userName, userPwd }))
        //{
        //    Response.Redirect("ErrorSQLZR.aspx");
        //    return;
        //}

        if (userType == "person")
            PersonLogin(userName, userPwd);
        if (userType == "company")
            companyLogin(userName, userPwd);
        if (userType == "admin")
            adminLogin(userName, userPwd);
    }

    private void adminLogin(String name, String password)
    {
        try
        {
            String userName = name;
            String userPwd = Common.Md5(password);

            String sql = "SELECT adminid,password from admin_base where username=@0";
            object[] parameters = new object[1];
            parameters[0] = userName;

            DataTable user = DB.GetDataSet(sql, parameters).Tables[0];
            if (user.Rows.Count > 0)
            {
                if (userPwd == user.Rows[0]["password"].ToString())
                {
                    Session["adminid"] = user.Rows[0]["adminid"].ToString();
                    Session["username"] = userName;
                    Response.Redirect("~/admin/AdminCenter.aspx");
                    return;
                }
            }

            Response.Redirect("~/admin/default.aspx?mode=1");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            Response.End();
        }
    }

    private void companyLogin(String name, String password)
    {
        try
        {
            String userName = name;
            String userPwd = Common.Md5(password);

            String sql = "SELECT comid,password,CompanyName from company_base where username=@0";
            object[] parameters = new object[1];
            parameters[0] = userName;

            DataTable user = DB.GetDataSet(sql, parameters).Tables[0];
            if (user.Rows.Count > 0)
            {
                if (userPwd == user.Rows[0]["password"].ToString())
                {


                    Session["comid"] = user.Rows[0]["comid"].ToString();
                    Session["username"] = userName;
                    Session["CompanyName"] = user.Rows[0]["CompanyName"].ToString();
                    Session["perid"] = null;
                    if (!isBackRefUrl())
                        Response.Redirect("Company.aspx");
                    return;
                }
            }

            Response.Write("<script>alert('账号密码错误或是用户类型选择错误!');location.href = 'index.aspx';</script>");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            Response.End();
        }
    }

    private void PersonLogin(String name, String password)
    {
        try
        {
            String userName = name;
            String userPwd = Common.Md5(password);

            String sql = "SELECT perid,password from personal_base where username=@0";
            object[] parameters = new object[1];
            parameters[0] = userName;

            DataTable user = DB.GetDataSet(sql, parameters).Tables[0];
            if (user.Rows.Count > 0)
            {
                if (userPwd == user.Rows[0]["password"].ToString())
                {
                    Session["perid"] = user.Rows[0]["perid"].ToString();
                    Session["username"] = userName;
                    Session["comid"] = null;
                    if (!isBackRefUrl())
                        Response.Redirect("p_person.aspx");
                    return;
                }
            }

            Response.Write("<script>alert('账号密码错误或是用户类型选择错误!');location.href = 'index.aspx';</script>");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            Response.End();
        }

    }

    private bool isBackRefUrl()
    {
        bool ret = false;
        if (Request.QueryString["refurl"] != null && Convert.ToString(Request.QueryString["refurl"]).Trim() != "")
        {
            String refurl = Request.QueryString["refurl"];
            if (!refurl.Contains("index.aspx") && !refurl.Contains("register1.aspx") && !refurl.Contains("Person.aspx"))
            {
                Response.Redirect(refurl);
                ret = true;
            }
        }

        return ret;
    }
}

