
jQuery.extend(Array.prototype, {
    //���ⷽ��������������ͨ����
    remove: function(item) {
        var array = this.clone();
        this.length = 0;
        for (var i = 0; i < array.length; i++) {
            if (array[i].id != item) this.push(array[i]);
        }
        return this;
    },

    //���ⷽ��������������ͨ����
    has: function(item) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] == item) return true;
            if (typeof item == "object" && this[i].id == item.id) return true;
        }
        return false;
    },
    //���ⷽ����������ĸ���
    GetFather: function(item) {
        for (var i = 0; i < this.length; i++) {
            if (this[i].parObj == null) continue;
            if (this[i].parObj.id == item.id) return true;
            if (typeof item == "object" && this[i].id == item.id) return true;
        }
        return false;
    },
    parItems: getLoc(), //function() { return getLoc(); },//updated by �κ��Σ���������ѡ������ʽ����
    //���ⷽ����������ĸ�����
    GetFaFather: function(item) {

        for (var i = 0; i < this.length; i++) {
            if (this[i].parObj == null) continue;
            if (this[i].parObj.parObj == null) continue;
            var parItem = this.parItems[parseInt(this[i].parObj.parObj)];
            if (parItem != null) {
                if (parItem.id == item.id)
                    return true;
            } else {
                if (typeof this[i].parObj.parObj == "object" && this[i].parObj.parObj.id == item.id)
                    return true;
            }
        }
        return false;
    },

    //���ⷽ��������������ͨ����
    findById: function(id) {
        for (var i = 0; i < this.length; i++) {
            if (this[i].id == id) {
                this[i].parObj = null;
                return this[i];
            }
            if (this[i].subItems != null && this[i].subItems != "undefined") {
                for (var j = 0; j < this[i].subItems.length; j++) {
                    if (this[i].subItems[j].id == id) {
                        this[i].subItems[j].parObj = this[i];
                        return this[i].subItems[j];
                    }
                    if (this[i].subItems[j].subItems != null && this[i].subItems[j].subItems != "undefined") {
                        for (var k = 0; k < this[i].subItems[j].subItems.length; k++) {
                            if (this[i].subItems[j].subItems[k].id == id) {
                                this[i].subItems[j].subItems[k].parObj = this[i].subItems[j];
                                this[i].subItems[j].subItems[k].parObj.parObj = this[i];
                                return this[i].subItems[j].subItems[k];
                            }
                        }
                    }
                }
            }
        }
        return null;
    },
    //���ⷽ��������������ͨ���飬���ط������ڶ������������ж��ǲ���ֻ����һ���ڵ�
    //
    findById: function(id, isFromRoot) {
        for (var i = 0; i < this.length; i++) {
            if (this[i].id == id) {
                this[i].parObj = null;
                return this[i];
            }
            if (isFromRoot)
                continue;
            if (this[i].subItems != null && this[i].subItems != "undefined") {
                for (var j = 0; j < this[i].subItems.length; j++) {
                    if (this[i].subItems[j].id == id) {
                        this[i].subItems[j].parObj = this[i];
                        return this[i].subItems[j];
                    }
                    if (this[i].subItems[j].subItems != null && this[i].subItems[j].subItems != "undefined") {
                        for (var k = 0; k < this[i].subItems[j].subItems.length; k++) {
                            if (this[i].subItems[j].subItems[k].id == id) {
                                this[i].subItems[j].subItems[k].parObj = this[i].subItems[j];
                                this[i].subItems[j].subItems[k].parObj.parObj = this[i];
                                return this[i].subItems[j].subItems[k];
                            }
                        }
                    }
                }
            }
        }
        return null;
    },

    clear: function() {
        this.length = 0;
        return this;
    },

    clone: function() {
        return [].concat(this);
    }
});

var requestFromStr = {
    QueryString: function(Str, val) {
        var uri = Str.substring(0, 1) == "?" ? Str : "?" + Str;
        var re = new RegExp("[&?]" + val + "=([^&?]*)", "ig");
        return ((uri.match(re)) ? (uri.match(re)[0].substr(val.length + 2)) : "");
    }
};



function locConverter(locIDs) {
    var arrLoc = locIDs.split(",");
    var temp = [];
    for (var i = 0; i < arrLoc.length; i++) {
        temp.push(ConverterLoc(arrLoc[i]));
    }
    return temp;
}

function traversal(id, items) {
    var p = items.findById(id);
    if (p != null) {
        return { id: p.id, name: p.name, parObj: null };
    }
    else {
        var subItems, c;
        for (var i = 0; i < items.length; i++) {
            p = items[i];
            c = p.subItems.findById(id);
            if (c != null) return { id: c.id, name: c.name, parObj: { id: p.id, name: p.name, parObj: null} };
        }
    }
    return null;
}

function dbcToSbc(str) {
    return str.replace(/��/g, "(").replace(/��/g, ")");
}
function addSpan(str) {
    str = dbcToSbc(str);
    if (str.length > 9) str = "<span>" + str + "</span>";
    return str;
}
var PopupSelector = {
    loadSelected: function(url) {
        var temp = [];
        var selCatParentIDs = requestFromStr.QueryString(url, "occParentIDList");
        if (selCatParentIDs != "") {
            if (selCatParentIDs.indexOf(",") > 0) selCatParentIDs = selCatParentIDs.split(",");
            else {
                selCatParentIDs = selCatParentIDs.replace(/%2C/g, "%2c");
                selCatParentIDs = selCatParentIDs.split("%2c");
            }
        }
        var selCatIDs = requestFromStr.QueryString(url, "occIDList");
        if (selCatIDs.indexOf(",") > 0) selCatIDs = selCatIDs.split(",");
        else {
            selCatIDs = selCatIDs.replace(/%2C/g, "%2c");
            selCatIDs = selCatIDs.split("%2c");
        }
        var addCatID = requestFromStr.QueryString(url, "addOccIDList");
        if (addCatID != "") {
            selCatIDs.clear();
            selCatIDs[0] = addCatID;
        }
        this._selItems["cat"].clear();
        var allCats = getCat();
        //�������addOccIDList�������occIDList��occParentIDList
        if (addCatID != "") {//|| selCatParentIDs == "") {//�޸���������������ְ��������ʧ��������κ��Σ�2010-8-23
            var catItem;
            for (var i = 0; i < selCatIDs.length; i++) {
                catItem = traversal(selCatIDs[i], allCats);
                if (catItem != null) {
                    this._selItems["cat"].push(catItem);
                    temp.push(catItem.name);
                }
            }
        }
        if (addCatID == "" && selCatParentIDs == "") {
            var cateIdList = new Array();
            for (var i = 0; i < selCatIDs.length; i++) {
                var cateItem = allCats.findById(selCatIDs[i]);
                if (cateItem != null) {
                    if (cateItem.parObj == null)
                        cateIdList.push(cateItem.id);
                    else
                        cateIdList.push(cateItem.parObj.id);
                }
            }
            selCatParentIDs = cateIdList;
        }
        
        //ͨ��״����occIDList��occParentIDList���е�״��
        if (selCatIDs.length > 0 && selCatIDs[0] != "" && selCatParentIDs != "" && addCatID == "") {
            for (var i = 0; i < selCatParentIDs.length; i++) {
                if (selCatParentIDs[i] == selCatIDs[i]) {
                    if (selCatIDs[i] != 255) {
                        var catItem = allCats.findById(selCatIDs[i]);
                        this._selItems["cat"].push({ id: catItem.id, name: catItem.name, parObj: null });
                        temp.push(catItem.name);
                    }
                }
                else {
                    var parCatItem = allCats.findById(selCatParentIDs[i]);
                    var subCatItem = parCatItem.subItems.findById(selCatIDs[i]);
                    this._selItems["cat"].push({ id: subCatItem.id, name: subCatItem.name, parObj: { id: parCatItem.id, name: parCatItem.name, parObj: null} });
                    temp.push(subCatItem.name);
                }
            }
        }

        jQuery("#txtCat").val(temp.join("+"));
        this.InitClass(temp, "cat");
        temp.length = 0;

        var selLocIDs = requestFromStr.QueryString(url, "myLocIDList");
        if (selLocIDs.indexOf(",") > 0) selLocIDs = selLocIDs.split(",");
        else {
            selLocIDs = selLocIDs.replace(/%2C/g, "%2c");
            selLocIDs = selLocIDs.split("%2c");
        }
        // selLocIDs = locConverter(selLocIDs.replace(/%2C/g, "%2c").replace(/%2c/g, ","));
        var selLocParentIDs = requestFromStr.QueryString(url, "myLocParentIDList");
        if (selLocParentIDs != "") {
            if (selLocParentIDs.indexOf(",") > 0) selLocParentIDs = selLocParentIDs.split(",");
            else {
                selLocParentIDs = selLocParentIDs.replace(/%2C/g, "%2c");
                selLocParentIDs = selLocParentIDs.split("%2c");
            }
            //selLocParentIDs = locConverter(selLocParentIDs);
        }
        //        if (selLocParentIDs.indexOf(",") > 0) selLocParentIDs = selLocParentIDs.split(",");
        //        else selLocParentIDs = selLocParentIDs.split("%2c");

        //var selLocIDs = requestFromStr.QueryString(url, "myLocIDList");
        //selLocIDs = locConverter(selLocIDs.replace(/%2C/g, "%2c").replace(/%2c/g, ","));
        //        if (selLocIDs.indexOf(",") > 0) selLocIDs = selLocIDs.split(",");
        //        else selLocIDs = selLocIDs.split("%2c");

        var addLocID = requestFromStr.QueryString(url, "addLocIDList");
        if (addLocID != "") {
            selLocIDs.clear();
            selLocIDs[0] = addLocID;
        }

        if (selLocParentIDs == "" && selLocIDs != "") {
            var arrayParentLocIds = new Array();
            for (var i = 0; i < selLocIDs.length; i++) {
                var item = this.allItems.loc().findById(selLocIDs[i]);
                if (item.parObj == null)
                    arrayParentLocIds.push(item.id);
                else
                    arrayParentLocIds.push(item.parObj.id);
            }
            selLocParentIDs = arrayParentLocIds;
            //alert(selLocParentIDs);
        }
        // alert(document.referrer);
        //���������� 
        this._selItems["loc"].clear();
        var allLocs = getLoc();
        //�������addLocIDList�������myLocIDList��myLocParentIDList
        if (addLocID != "" || selLocParentIDs == "") {
            var locItem;

            for (var i = 0; i < selLocIDs.length; i++) {
                locItem = allLocs.findById(selLocIDs[i]);
                if (locItem != null) {
                    this._selItems["loc"].push(locItem);
                    if (locItem.parObj != null) {
                        if (locItem.parObj.parObj != null) {
                            temp.push(locItem.parObj.parObj.name + "-" + locItem.parObj.name + "-" + locItem.name);
                        }
                        else {
                            temp.push(locItem.parObj.name + "-" + locItem.name);
                        }
                    }
                    else {
                        temp.push(locItem.name);
                    }
                }
            }

            //            var parlocItem;
            //            for (var j = 0; j < selLocParentIDs.length; j++) {
            //                //                parlocItem = traversal(selLocParentIDs[j], allLocs);
            //                parlocItem = allLocs.findById(selLocParentIDs[j]);
            //                for (var i = 0; i < selLocIDs.length; i++) {
            //                    //                    locItem = traversal(selLocIDs[i], allLocs);
            //                    locItem = allLocs.findById(selLocIDs[i]);
            //                    if (locItem != null) {
            //                        if (parlocItem != null && locItem.parObj != null) {
            //                            this._selItems["loc"].push({ id: locItem.id, name: locItem.name, parObj: { id: parlocItem.id, name: parlocItem.name, parObj: null} });
            //                            if (parlocItem.parObj != null) {
            //                                temp.push(parlocItem.parObj.name + "-" + parlocItem.name + '-' + locItem.name);
            //                            }
            //                            else {
            //                                temp.push(parlocItem.name + '-' + locItem.name);
            //                            }
            //                            //this._selItems["loc"].push(locItem);
            //                            //temp.push(locItem.name);
            //                        }
            //                        else {
            //                            this._selItems["loc"].push(locItem);
            //                            temp.push(locItem.name);
            //                        }
            //                    }
            //                }
            //            }
        }

        //ͨ��״����myLocIDList��myLocParentIDList���е�״��
        if (selLocIDs.length > 0 && selLocIDs[0] != "" && selLocParentIDs != "" && addLocID == "") {
            for (var i = 0; i < selLocParentIDs.length; i++) {
                if (selLocParentIDs[i] == selLocIDs[i] || selLocParentIDs[i] == -1) {
                    if (selLocIDs[i] != 255) {
                        var locItem = allLocs.findById(selLocIDs[i]);
                        this._selItems["loc"].push({ id: locItem.id, name: locItem.name, parObj: null });
                        temp.push(locItem.name);
                    }

                }
                else {

                    var curLocItem = allLocs.findById(selLocParentIDs[i]);
                    if (curLocItem != null) {
                        var subLocItem = curLocItem.subItems.findById(selLocIDs[i]);
                        //this._selItems["loc"].push({ id: subLocItem.id, name: subLocItem.name, parObj: { id: curLocItem.id, name: curLocItem.name, parObj: null} });
                        //temp.push(subLocItem.name)
                        var parItems = this.allItems["loc"]();
                        var location = '';
                        var curLocItem = allLocs.findById(selLocParentIDs[i]);
                        if (curLocItem != null && curLocItem.parObj != null) {
                            var parItem = parItems[parseInt(curLocItem.parObj)];
                            if (parItem == "undefined" || parItem == null)
                                parItem = curLocItem.parObj;
                            if (parItem.name == curLocItem.parObj.name) {
                                location = parItem.name + '-' + curLocItem.name + '-' + subLocItem.name;
                                this._selItems["loc"].push({ id: subLocItem.id, name: subLocItem.name, parObj: { id: curLocItem.id, name: curLocItem.name, parObj: { id: parItem.id, name: parItem.name, parObj: null}} });
                            }
                        }
                        else {
                            location = curLocItem.name + '-' + subLocItem.name;
                            this._selItems["loc"].push({ id: subLocItem.id, name: subLocItem.name, parObj: { id: curLocItem.id, name: curLocItem.name, parObj: null} });
                        }
                        temp.push(location);
                    }
                    //                        if (parLocItem.parObj == null)
                    //                            this._selItems["loc"].push({ id: subLocItem.id, name: subLocItem.name, parObj: { id: parLocItem.id, name: parLocItem.name, parObj: null} });
                    //                        else
                    //                            this._selItems["loc"].push({ id: subLocItem.id, name: subLocItem.name, parObj: { id: parLocItem.id, name: parLocItem.name, parObj: { id: parLocItem.parObj.id, name: parLocItem.parObj.name, parObj: null}} });
                    //                    }
                    //var subLocItem = parLocItem.subItems.findById(selLocIDs[i]);
                    //this._selItems["loc"].push({ id: subLocItem.id, name: subLocItem.name, parObj: { id: parLocItem.id, name: parLocItem.name, parObj: null} });
                    //temp.push(subLocItem.name);
                }
            }
        }

        jQuery("#txtLoc").val(temp.join("+"));
        this.InitClass(temp, "loc");
        temp.length = 0;
        var selIndIDs = requestFromStr.QueryString(url, "indIDList");
        if (selIndIDs.indexOf(",") > 0) selIndIDs = selIndIDs.split(",");
        else {
            selIndIDs = selIndIDs.replace(/%2C/g, "%2c");
            selIndIDs = selIndIDs.split("%2c");
        }
        //ת����ҵ�ֵ䲻һ�µ�����
        //selIndIDs = ConverterInd(selIndIDs.replace(/%2C/g, "%2c").replace(/%2c/g, ",")).split(",");
        //        if (selIndIDs.indexOf(",") > -1) selIndIDs = selIndIDs.split(",");
        //        else selIndIDs = selIndIDs.split("%2c");
        var addIndID = requestFromStr.QueryString(url, "addIndIDList");
        var allInds = getInd();
        var addIndItem = allInds.findById(addIndID);
        this._selItems["ind"].clear();
        if (addIndItem != null) {
            this._selItems["ind"].push({ id: addIndItem.id, name: addIndItem.name, parObj: null });
            temp.push(addIndItem.name);
        }

        //        if(selIndIDs[0]==255)
        //        {
        //             this._selItems["ind"].push({ id: 255, name: "����", parObj: null });
        //             temp.push("����");
        //        }

        if (selIndIDs.length > 0 && selIndIDs[0] != "" && addIndItem == null) {
            for (var i = 0; i < selIndIDs.length; i++) {
                if (selIndIDs[i] != 255) {
                    var indItem = allInds.findById(selIndIDs[i]);
                    if (indItem == null) continue;
                    this._selItems["ind"].push({ id: indItem.id, name: indItem.name, parObj: null });
                    temp.push(indItem.name);
                }
            }
        }
        jQuery("#txtInd").val(temp.join("+"));
        this.InitClass(temp, "ind");
        temp.length = 0;

        // ��˾���
        if (jQuery("#txtAdvanceCompType").length > 0) {
            var companyTypeID = requestFromStr.QueryString(url, "companyTypeIDList");
            if (companyTypeID != "") {
                if (companyTypeID.indexOf(",") > 0) companyTypeID = companyTypeID.split(",");
                else {
                    companyTypeID = companyTypeID.replace(/%2C/g, "%2c");
                    companyTypeID = companyTypeID.split("%2c");
                }
            }
            var allCompanyType = getCompanyType();
            if (companyTypeID.length > 0 && companyTypeID[0] != "") {
                for (var i = 0; i < companyTypeID.length; i++) {
                    if (companyTypeID[i] != 255) {
                        var companyTypeItem = allCompanyType.findById(companyTypeID[i]);
                        if (companyTypeItem == null) continue;
                        this._selItems["comptype"].push({ id: companyTypeItem.id, name: companyTypeItem.name, parObj: null });
                        temp.push(companyTypeItem.name);
                    }
                }
            }
            jQuery("#txtAdvanceCompType").val(temp.join("+"));
            temp.length = 0;
        }

    },
    RenderSelectedHTML: function(selectedItem, type) {
        var location = '';
    },
    InitClass: function(temp, type) {
        if (temp.length != 0) {
            if (type == "cat") {
                $("#txtCat").removeClass("inp_txt inp_txtsel inp_wl inp_cue gray");
                $("#txtCat").addClass("inp_txt inp_txtsel inp_wl");
            }
            if (type == "loc") {
                $("#txtLoc").removeClass("inp_txt inp_txtsel inp_wm inp_cue gray");
                $("#txtLoc").addClass("inp_txt inp_txtsel inp_wm");
            }
            if (type == "ind") {
                $("#txtInd").removeClass("inp_txt inp_txtsel inp_wm inp_cue gray");
                $("#txtInd").addClass("inp_txt inp_txtsel inp_wm");
            }

        }
        else {
            if (type == "cat") {
                $("#txtCat").removeClass("inp_txt inp_txtsel inp_wl");
                $("#txtCat").addClass("inp_txt inp_txtsel inp_wl inp_cue gray");
                $("#txtCat").val("��ѡ��ְҵ���")
            }
            if (type == "loc") {
                $("#txtLoc").removeClass("inp_txt inp_txtsel inp_wm");
                $("#txtLoc").addClass("inp_txt inp_txtsel inp_wm inp_cue gray");
                $("#txtLoc").val("��ѡ�����ص�")
            }
            if (type == "ind") {
                $("#txtInd").removeClass("inp_txt inp_txtsel inp_wm");
                $("#txtInd").addClass("inp_txt inp_txtsel inp_wm inp_cue gray");
                $("#txtInd").val("��ѡ����ҵ���");
            }
        }
    },
    popup: function(type, ref, selectdtids, tagPrefix, checkType) {
        this.AarearenderSelItemEleId = selectdtids;
        this.AareatagPrefix = tagPrefix;
        this.AarearenderSelItemDiv = ref;
        var selLocIDs;
        if (this._box == null) this._box = jQuery("#popupSelector");
        if (this._subBox == null) this._subBox = document.getElementById("subItems");
        this._ref = ref;
        this._type = type.toString().toLowerCase();
        //��ʼ���˵�����
        if (this.AarearenderSelItemEleId != null)
            selLocIDs = document.getElementById(this.AarearenderSelItemEleId).value.split(',');
        var allLocs = getLoc();
        this._curItems.length = 0;
        //        if (selLocIDs != null && selLocIDs.length > 0) {
        //            for (var i = 0; i < selLocIDs.length; i++) {
        //                if (selLocIDs[i] != 255) {
        //                    var locItem = allLocs.findById(selLocIDs[i]);
        //                    if (locItem == null) continue;
        //                    this._curItems.push(locItem);
        //                    //temp.push(indItem.name);
        //                }
        //            }
        //        }
       // alert(this._selItems[this._type]);
        this._curItems = this._selItems[this._type].clone();
        if (arguments.length == 3) {
            this._checkType = checkType;
        }
        //        this._style.position = "absolute";
        //        this._style.zIndex = "10001";
        //        this._style.top = 100 + webPB.getScrollPos().top + "px";
        //        this._style.left = webPB.getWAndHOfWindow().w / 2 - 350 + "px";
        var offset = jQuery("#" + ref.id).offset();
        this._style.left = offset.left;
        this._style.top = offset.top;
        this.render();
    },

    render: function(event) {
        var pos = { top: (this._style.top + this._style.offset.levelOne.Y), left: this._style.left + this._style.offset.levelOne.X };
        if (this._type != "cat" && this._type != "comptype") {
            //            if (document.location.href.toLowerCase().indexOf("searchjob.chinahr.com") > -1)
            //                pos.left -= (this._style.width[this._type] - 384);
            if (this._type == "ind")
                pos.left = jQuery(jQuery("#txtCat")[0]).offset().left;
            else if (this._type == "loc") {
                //����ҳ����������ص�λ��
                if (this.InSalaryPage) {
                    pos.left = this._style.left;
                }
                else if (this.InAdvanceSearchPage) {
                    pos.left = this._style.left;
                }
                else {
                    pos.left = this._style.left - this._style.offset.levelOne[this._type].X;
                }
            }

        }
        var scrolTop;
        if (jQuery.browser.msie && jQuery.browser.version == '6.0') scrolTop = document.body.scrollTop;
        else scrolTop = document.documentElement.scrollTop;
        //alert(scrolTop);
        //��ǰ���ڶ�����ʾ����λ�ÿ��õĸ߶ȣ�������ø߶�С�ڵ�����ĸ߶ȣ�����е���
        var remainHeight = jQuery(window).height() - pos.top + scrolTop;
        if (remainHeight < this._style.height[this._type]) pos.top = pos.top - (this._style.height[this._type] - remainHeight);
        //�����ǰ���ڸ߶Ȳ�������ʾ������߶ȣ��򶥲����뼴��
        if (this._style.height[this._type] > jQuery(window).height()) pos.top = scrolTop;
        var pslayer = jQuery("#pslayer");
        for (var i = 0; i < this._types.length; i++) {
            pslayer.removeClass(this._style.className.levelOne[this._types[i]]);
        }
        pslayer.addClass(this._style.className.levelOne[this._type]);
        if (this.InSalaryPage) {
            this._gtYourSelected["ind"] = '��ѡ�������ҵ���';
        }

        jQuery("#selectingHeader").html(this._gtYourSelected[this._type]);


        jQuery("#psHeader").html(this._gtPopupSelectorHeader[this._type]);

        //this._curItems = this._selItems[this._type];
        var html = [];
        var popupLayer;
        var parItems = this.allItems[this._type]();
        var start = 0;
        var end = parItems.length;
        if (this._type == "loc") {
            start = 0;
            end = 34; //����������ǰ35λ�ǹ���ʡ,���������ȫ������34
            jQuery("#subHeader1").html("<span>����ʡ�У�</span>");
           
            for (var i = end; i < parItems.length; i++) {
                if (this._curItems.has({ id: parItems[i].id, name: parItems[i].name, parObj: null })) {
                    html.push("<li id=jQuery" + i + " name=" + parItems[i].id + " class=\"layon\"><a href=\"javascript:void(0);\">");
                }
                else {
                    html.push("<li id=jQuery" + i + " name=" + parItems[i].id + " class=\"nonelay\"><a href=\"javascript:void(0);\">");
                }

                html.push("<label for=\"pcbx");
                html.push(parItems[i].id);
                html.push("\">");
                html.push("<input id=\"pcbx");
                html.push(parItems[i].id);
                html.push("\" type=\"" + PopupSelector._checkType + "\" value=\"");
                html.push(parItems[i].id);
                html.push("@");
                html.push(parItems[i].name);
                html.push("\"");
                if (this._curItems.has({ id: parItems[i].id, name: parItems[i].name, parObj: null })) html.push(" checked");
                html.push(" onclick=\"PopupSelector.click(" + i + ",this, null," + parItems[i].id + ")\" />");
                html.push(parItems[i].name);
                html.push("</label>");
                html.push("</a></li>");
            }
            jQuery("#subHeader1").show();
            jQuery("#subHeader2").show();
            jQuery("#allItems2").html(html.join("")).show();
        }
        else {
            jQuery("#subHeader1").hide();
            jQuery("#subHeader2").hide();
            jQuery("#allItems2").hide();
        }

        html = [];
        var IsAllOption = false;
        for (var j = 0; j < this._curItems.length; j++) {
            if (this._curItems[j].id == "999999") {
                IsAllOption = true;
            }
        }
        //        if (document.getElementById(this.AarearenderSelItemEleId).plShowAllCountry.toLowerCase() == "false")
        //            end--;
        for (var i = start; i < end; i++) {
            var parItem = parItems[i];
            if (parItem.subItems && parItem.subItems.length > 1) {

                if (this._curItems.has({ id: parItem.id, name: parItem.name, parObj: null }) || this._curItems.GetFather({ id: parItem.id, name: parItem.name, parObj: null }) || this._curItems.GetFaFather({ id: parItem.id, name: parItem.name, parObj: null })) {
                    html.push("<li id=jQuery" + i + " name=" + parItem.id + " class=\"layicon\" onmouseover=\"PopupSelector.showSubItems(");
                }
                else {
                    html.push("<li id=jQuery" + i + " name=" + parItem.id + " onmouseover=\"PopupSelector.showSubItems(");
                }
                html.push(i);
                html.push("," + parItem.id + ", this, true)\" onmouseout=\"PopupSelector.hideSubItems(this)\">");
                html.push("<a href=\"javascript:void(0);\">");

                //html.push("<label >");

                html.push("<input id=\"pcbx");
                html.push(parItem.id);
                html.push("\" type=\"" + PopupSelector._checkType + "\" value=\"");
                html.push(parItem.id);
                html.push("@");
                html.push(parItem.name);
                html.push("\"");
                if (IsAllOption) {
                    if (parItem.id != "999999")
                        html.push(" disabled=\"true\"");
                    html.push(" checked");
                }
                else
                    if (this._curItems.has({ id: parItem.id, name: parItem.name, parObj: null })) html.push(" checked");
                html.push(" onclick=\"PopupSelector.click(");
                html.push(i + ",this, null," + parItem.id + ")\" />");
                html.push(dbcToSbc(parItem.name));

                //html.push("</label>");
                html.push("</a></li>");
            }

            else {
                if (this._curItems.has({ id: parItem.id, name: parItem.name, parObj: null }))
                    html.push("<li id=jQuery" + i + " name=" + parItem.id + " class=\"layon\">");
                else
                    html.push("<li id=jQuery" + i + " name=" + parItem.id + " class=\"nonelay\">");
                html.push("<a href=\"javascript:void(0);\">");

                html.push("<label for=\"pcbx");
                html.push(parItems[i].id);
                html.push("\">");
                html.push("<input id=\"pcbx");
                html.push(parItem.id);
                html.push("\" type=\"" + PopupSelector._checkType + "\" value=\"");
                html.push(parItem.id);
                html.push("@");
                html.push(parItem.name);
                html.push("\"");
                if (IsAllOption) {
                    if (parItem.id != "999999")
                        html.push(" disabled=\"true\"");
                    html.push(" checked");
                }
                else
                    if (this._curItems.has({ id: parItem.id, name: parItem.name, parObj: null })) html.push(" checked");
                html.push(" onclick=\"PopupSelector.click(");
                html.push(i + ",this, null," + parItem.id + ")\" />");
                html.push(dbcToSbc(parItem.name));

                html.push("</label>");
                html.push("</a></li>");
            }

        }
        jQuery("#allItems1").html(html.join("").toString());
        html.length = 0;

        jQuery("#divSelecting").css("display", (this._curItems.length == 0) ? "none" : "block");
        var displayNoSelected = (this._curItems.length == 0) ? "block" : "none";
        if (this._type == "cat") {
            jQuery("#noSelectedCat").css("display", displayNoSelected);
            jQuery("#noSelectedLoc").hide();
        }
        else if (this._type == "loc") {
            jQuery("#noSelectedLoc").css("display", displayNoSelected);
            jQuery("#noSelectedCat").hide();
        }
        else {
            jQuery("#noSelectedCat").hide();
            jQuery("#noSelectedLoc").hide();
        }
        for (var i = 0; i < this._curItems.length; i++) {
            //            html.push("<li id=\"");
            //            html.push(this._curItems[i].id);
            //            if (this._curItems[i].parObj) {
            //                if (this._curItems[i].parObj.parObj != null) {
            //                    html.push("\"><a href=\"javascript:void(0);\" onclick=\"PopupSelector.removelv3(");
            //                    html.push(this._curItems[i].id);
            //                    html.push("," + this._curItems[i].parObj.id);
            //                    html.push("," + this._curItems[i].parObj.parObj.id);
            //                    for (var m = 0; m < parItems.length; m++) {
            //                        if (parItems[m].id == this._curItems[i].parObj.parObj.id) html.push("," + m + ")\">");
            //                    }
            //                    parItem = this._curItems[i].parObj.parObj;
            //                    nameString = parItem.name + "-" + this._curItems[i].parObj.name + "-" + this._curItems[i].name;
            //                }
            //                else {
            //                    html.push("\"><a href=\"javascript:void(0);\" onclick=\"PopupSelector.remove(");
            //                    html.push(this._curItems[i].id);
            //                    html.push("," + this._curItems[i].parObj.id);
            //                    for (var m = 0; m < parItems.length; m++) {
            //                        if (parItems[m].id == this._curItems[i].parObj.id) html.push("," + m + ")\">");
            //                    }
            //                    nameString = this._curItems[i].parObj.name + "-" + this._curItems[i].name;
            //                }
            //            } else {
            //                html.push("\"><a href=\"javascript:void(0);\" onclick=\"PopupSelector.remove(");
            //                html.push(this._curItems[i].id);
            //                html.push(")\">");
            //                nameString = this._curItems[i].name;
            html.push("<li id=\"");
            html.push(this._curItems[i].id);
            html.push("\"><a href=\"###\" onclick=\"PopupSelector.remove(");
            html.push(this._curItems[i].id);
            if (this._curItems[i].parObj != null) {
                if (this._curItems[i].parObj.parObj != null) {
                    html.push("," + this._curItems[i].parObj.parObj.id + ")\">");
                }
                else {
                    html.push("," + this._curItems[i].parObj.id + ")\">");
                }
            }
            else
                html.push(")\">");
            var nameString;

            if (this._curItems[i].parObj && this._type == "loc") {
                if (this._curItems[i].parObj.parObj != null) {
                    parItem = parItems[parseInt(this._curItems[i].parObj.parObj)];
                    if (parItem == "undefined" || parItem == null) parItem = this._curItems[i].parObj.parObj;
                    if (parItem.name == this._curItems[i].parObj.name)
                        nameString = this._curItems[i].parObj.name + "-" + this._curItems[i].name;
                    else
                        nameString = parItem.name + "-" + this._curItems[i].parObj.name + "-" + this._curItems[i].name;
                } else {
                    nameString = this._curItems[i].parObj.name + "-" + this._curItems[i].name;
                }
            }
            else
                nameString = this._curItems[i].name;
            //}

            html.push(dbcToSbc(nameString));
            html.push("</a></li>");
        }
        jQuery("#selecting").html(html.join(""));
        if (this._type == "ind" || this._type == "comptype") {
            jQuery("#divSelecting").show();
            jQuery("#selecting").hide();
        }
        else jQuery("#selecting").show();
        jQuery("#shield").width(this._style.width[this._type]).height(this._style.height[this._type]);
        jQuery(this._box).css(pos).show();
        jQuery("#mask").height(jQuery(document).height()).show();
        //        var tempK = jQuery("html");
        //        jQuery("html").css("overflow", "hidden");

        //��λ����
        jQuery("#pcbx30000").focus();

    },

    close: function() {
        jQuery("#mask").hide();
        //        jQuery("html").css("overflow", "auto");
        this._ref = null;
        jQuery(this._box).hide();
    },

    OK: function() {
        var html = [],
        tmpSelectedItem = popupLayer.selectedItems;
        var renderSelItemDiv = this.AarearenderSelItemDiv;
        var renderSelIds = this.AarearenderSelItemEleId;
        var renderfix = this.AareatagPrefix;
        var ids = [];
        var temp = [];
        var parthis = this;
        jQuery.each(this._curItems, function() {
            var nameString;
            if (this.parObj && parthis._type == "loc") {
                var parItemsVal = parthis.allItems[parthis._type]();
                if (this.parObj.parObj != null) {
                    parItem = parItemsVal[parseInt(this.parObj.parObj)];
                    if (parItem == "undefined" || parItem == null) parItem = this.parObj.parObj;
                    if (parItem.name == this.parObj.name)
                        nameString = this.parObj.name + "-" + this.name;
                    else
                        nameString = parItem.name + "-" + this.parObj.name + "-" + this.name;
                } else {
                    nameString = this.parObj.name + "-" + this.name;
                }
            }
            else
                nameString = this.name;
            temp.push(nameString);
            html.push('<div class="list_m" id="' + renderfix + '_divSelItem_' + this.id + '">');
            html.push('<div class="list_c">');
            html.push(nameString);
            html.push('</div>');
            html.push('<input type="button" value="ɾ��" title="ɾ��"');
            html.push('onclick="pLayer.remove(\'' + renderfix + '_divSelItem_' + this.id + '\',\'' + renderSelIds + '\',\'' + renderSelItemDiv + '\')" />');
            html.push('</div>');
            ids.push(this.id);
        });
        $(renderSelItemDiv).innerHTML = html.join("");
        $("#renderSelIds").val(ids.join(','));
        //document.getElementById(renderSelItemDiv).innerHTML = html.join("");
        //document.getElementById(renderSelIds).value = ids.join(',');
        if (this.InSalaryPage) {
            if (this._curItems) {
                if (this._type == "loc" && this._curItems[0] != null) {
                    jQuery("#hidLoc").val(this._curItems[0].id);
                }
                if (this._type == "ind" && this._curItems[0] != null) {
                    jQuery("#hidInd").val(this._curItems[0].id);
                }
                if (this._type == "cat" && this._curItems[0] != null) {
                    jQuery("#hidCat").val(this._curItems[0].id);
                }
            }
        }
        jQuery(this._ref).val(dbcToSbc(temp.join("+")));
        var idname="";
        for(i=0;i<ids.length;i++){
        	idname+=ids[i]+":"+dbcToSbc(temp[i])+",";
        	
        }
        if(idname!=""){
        	idname=idname.substring(0,idname.length-1);
        }
       
        $("#cityIdName").val(idname);
        //this.InitClass(temp, this._type);
        this._ref = null;
        this._selItems[this._type] = this._curItems.clone();
        
        this._curItems.clear();
        jQuery("#selecting").html("");
        jQuery("#mask").hide();
        jQuery(this._box).hide();
    },

    empty: function() {
        jQuery("#selecting").html("");
        jQuery("#allItems1 input").each(function(i) { this.checked = false; this.disabled = false; });
        jQuery("#allItems2 input").each(function(i) { this.checked = false; });
        jQuery("#allItems1 li").each(function(i) { if (this.className == "layicon") this.className = ""; if (this.className == "layon") this.className = "nonelay"; });
        jQuery("#allItems2 li").each(function(i) { if (this.className == "layicon") this.className = ""; if (this.className == "layon") this.className = "nonelay"; });
        this._curItems.clear();
        PopupSelector.showtips();
        //this.showHideSelecting(this);
    },
    InSalaryPage: false,
    InAdvanceSearchPage: false,
    click: function(ref, cbx, parObj, parName, lev) {
    	this._maxSize=3;
        // jQuery("#debugInfo").html("ref: " + ref + " cbx: " + cbx + " parObj:" + parObj + " parName: " + parName + " lev:" + lev);
        if (cbx.checked && this._curItems.length == this._maxSize) {
            alert(this._gtMaxLimit);
            cbx.checked = false;
            return;
        }
        var item = { id: cbx.value.split("@")[0], name: cbx.value.split("@")[1], parObj: parObj };
        var selecting = document.getElementById("selecting");
        var selItem = null;
        //
        if (this.InSalaryPage) {
            //PopupSelector.click(5,this, null,7000)
            jQuery(".sech_layb input[type='radio']").each(function(i) { this.checked = false; })
            jQuery("#subBox input[type='radio']").each(function(i) { this.checked = false; })
            if (this._type != "ind") {
                var tempType = this._type;
                jQuery(".layon").each(function(i) {
                    if (tempType == "loc") {
                        if (this.id == "jQuery1" || this.id == "jQuery2" || this.id == "jQuery3" || this.id == "jQuery4" || this.id == "jQuery32" || this.id == "jQuery33" || this.id == "jQuery34" || this.id == "jQuery35" || this.id == "jQuery36" || this.id == "jQuery37" || this.id == "jQuery38" || this.id == "jQuery39" || this.id == "jQuery40") {
                            this.className = 'nonelay';
                        } else {
                            this.className = '';
                        }
                    } else {
                        if (this.id == "jQuery29" || this.id == "jQuery31") {
                            this.className = 'nonelay';
                        } else {
                            this.className = '';
                        }
                    }
                });
            } else {
                jQuery(".layon").each(function(i) { this.className = 'nonelay'; });
            }
            jQuery(".layicon").each(function(i) { this.className = ''; });
            cbx.checked = true;
            selItem = "<a href=\"javascript:void(0);\" onclick=\"PopupSelector.remove(" + item.id + ",null);\">" + dbcToSbc(item.name) + "</a>";
            if (parObj != null) {
                selItem = "<a href=\"javascript:void(0);\" onclick=\"PopupSelector.remove(" + item.id + "," + parObj.id + ");\">" + dbcToSbc(item.name) + "</a>";
            }
            jQuery(selecting).html("<li id='" + parName + "'>" + selItem + "</li>");

            if (parObj != null) {
                document.getElementById('^' + ref).className = "layon";
                var id = parObj.id;
                jQuery("li[@name=" + id + "]").addClass("layicon");
            } else {
                document.getElementById('jQuery' + ref).className = "layon";
            }

            this._curItems.clear();
            this._curItems.push(item);
            this.showHideSelecting(this);
            PopupSelector.showtips();
            return;
        }
        if (cbx.checked) {
            if (parName != "999999") {
                selItem = document.createElement("li");
                selItem.id = item.id;
                if (parObj == null) {
                    //�Ƴ�2,3����ʼ
                    var parItem = this.allItems[this._type]()[ref];
                    var parthis = this;
                    jQuery(parthis._curItems).each(function() {
                        var tt = this.id;
                        itemSubstring = document.getElementById(tt);
                        if (itemSubstring != null) {
                            var tmp = false;
                            if (parItem.subItems && parItem.subItems.length > 0) {
                                for (var i = 0; i < parItem.subItems.length; i++) {
                                    if (parItem.subItems[i].id == tt) tmp = true;
                                    if (parItem.subItems[i].subItems && parItem.subItems[i].subItems.length > 0)
                                        jQuery(parItem.subItems[i].subItems).each(function() {
                                            if (this.id == tt) tmp = true;
                                        });
                                }
                            }
                            if (tmp == true) {
                                selecting.removeChild(itemSubstring);
                                parthis._curItems.remove(this.id);
                            }
                        }
                    });
                    //�Ƴ�2,3������
                    selItem.innerHTML = "<a href=\"javascript:void(0);\" onclick=\"PopupSelector.remove(" + item.id + ",null);\">" + dbcToSbc(item.name) + "</a>";
                }
                else {
                    var nameString;
                    if (lev == 3) {
                        var parItemsVal = this.allItems[this._type]();
                        var indexval = parseInt(parObj.parObj);
                        parItem = parItemsVal[indexval];
                        nameString = parItem.name + "-" + parObj.name + "-" + item.name;
                        selItem.innerHTML = "<a href=\"javascript:void(0);\" onclick=\"PopupSelector.removelv3(" + item.id + "," + parObj.id + "," + parItem.id + "," + parObj.parObj + ");\">" + dbcToSbc(nameString) + "</a>";
                    }
                    else {
                        //�Ƴ�3����ʼ
                        var parItem = this.allItems[this._type]()[parObj.parObj].subItems[ref];
                        var parthis = this;
                        jQuery(parthis._curItems).each(function() {
                            var tt = this.id;
                            itemSubstring = document.getElementById(tt);
                            if (itemSubstring != null) {
                                var tmp = false;
                                if (parItem.subItems && parItem.subItems.length > 0)

                                    jQuery(parItem.subItems).each(function() {
                                        if (this.id == tt) tmp = true;
                                    });
                                if (tmp == true) {
                                    selecting.removeChild(itemSubstring);
                                    parthis._curItems.remove(this.id);
                                }
                            }
                        });
                        //�Ƴ�3������
                        if (this._type == "loc") {
                            nameString = parObj.name + "-" + item.name;
                        }
                        else {
                            nameString = item.name;
                        }
                        selItem.innerHTML = "<a href=\"javascript:void(0);\" onclick=\"PopupSelector.remove(" + item.id + "," + parObj.id + "," + parObj.parObj + ");\">" + dbcToSbc(nameString) + "</a>";
                    }
                }
                selecting.appendChild(selItem);
                this._curItems.push(item);
            }
            else {
                var parthis = this;

                //�Ƴ���ǰѡ����ĵ���
                if (parthis._curItems.length > 0) {

                    jQuery(parthis._curItems).each(function() {
                        var tt = this.id;
                        itemSubstring = document.getElementById(tt);
                        if (itemSubstring != null) {
                            var tmp = false;
                            jQuery("#allItems2 input").each(function() {
                                if (this.value.split("@")[0] == tt) tmp = true;
                            });
                            if (tmp != true) {
                                selecting.removeChild(itemSubstring);
                                parthis._curItems.remove(this.id);
                            }
                        }
                    });

                }
                PopupSelector.showtips();
                //�������е���
                jQuery("#allItems1 input").each(function() {
                    if (this.id != "pcbx999999") {
                        var itemSubstring = null;
                        var selItemSubstring = null;
                        itemSubstring = { id: this.value.split("@")[0], name: this.value.split("@")[1], parObj: null };
                        selItemSubstring = document.createElement("li");
                        selItemSubstring.id = itemSubstring.id;
                        selItemSubstring.innerHTML = "<a href=\"javascript:void(0);\" onclick=\"PopupSelector.remove(" + itemSubstring.id + ",null);\">" + dbcToSbc(itemSubstring.name) + "</a>";
                        selecting.appendChild(selItemSubstring);
                        parthis._curItems.push(itemSubstring);
                    }
                });
            }
            this.showHideSelecting(this);
        }
        else {
            if (item.id == "999999") {
                var parthis = this;
                jQuery("#allItems1 input").each(function() {
                    if (this.id != "pcbx999999") {
                        var itemSubstring = null;
                        itemSubstring = document.getElementById(this.value.split("@")[0]);
                        if (itemSubstring != null) {
                            selecting.removeChild(itemSubstring);
                            parthis._curItems.remove(this.value.split("@")[0]);
                        }
                    }
                });
            }
            else {
                selItem = document.getElementById(item.id);
                selecting.removeChild(selItem);
                this._curItems.remove(item.id);
            }
            PopupSelector.showtips();
        }
        //������ʽ
        if (parObj == null) {//ѡ��ʡһ��������һ��ȫ��ѡ��
            var parItems = this.allItems[this._type]();
            parItem = parItems[ref];
            if (cbx.checked) {
                if (parItem.subItems && parItem.subItems.length > 1)
                    document.getElementById('jQuery' + ref).className = "layicon";
                else
                    document.getElementById('jQuery' + ref).className = "layon";

            }
            else {
                if ((parItem.subItems && parItem.subItems.length > 1))
                    document.getElementById('jQuery' + ref).className = "";
                else
                    document.getElementById('jQuery' + ref).className = "nonelay";


            }
            if (parName == "999999") {
                jQuery("#allItems1 input").each(function(i) {
                    if (this.id != "pcbx999999")
                        this.checked = this.disabled = cbx.checked;
                    var parItemSub = parItems[i];
                    if (cbx.checked) {
                        if (parItemSub.subItems && parItemSub.subItems.length > 1)
                            document.getElementById('jQuery' + i).className = "layicon";
                        else
                            document.getElementById('jQuery' + i).className = "layon";
                    }
                    else {
                        if (parItemSub.subItems && parItemSub.subItems.length > 1)
                            document.getElementById('jQuery' + i).className = "";
                        else
                            document.getElementById('jQuery' + i).className = "nonelay";
                    }
                }
                );
            }
            else {
                try {
                    if (parItem.subItems && parItem.subItems.length > 1)
                        var itemType = this._type;
                    jQuery("#subItems input").each(function(i) {
                        this.checked = this.disabled = cbx.checked;
                        var ItemSubCollection = parItem.subItems[i];
                        var idString = "^" + i;
                        if (itemType != "loc")
                            idString = "^" + (i + 1);
                        var subItems = document.getElementById(idString);
                        if (subItems != null) {
                            if (cbx.checked) {
                                if (ItemSubCollection.subItems && ItemSubCollection.subItems.length > 1) {
                                    subItems.className = "layicon";
                                }
                                else {
                                    subItems.className = "layon";
                                }
                            }
                            else {
                                if (ItemSubCollection.subItems && ItemSubCollection.subItems.length > 1)
                                    subItems.className = "";
                                else
                                    subItems.className = "nonelay";
                            }
                        }
                    });
                }
                catch (err) {

                }
            }
        }
        else {
            var parItems = this.allItems[this._type]();
            var indexString;
            for (var i = 0; i < parItems.length; i++) {
                if (parItems[i].id == parObj.id) {
                    parItem = parItems[i];
                    indexString = i;
                    break;
                }
            }
            if (cbx.checked) {
                if (parItem.subItems[ref].subItems && parItem.subItems[ref].subItems.length > 1)
                    document.getElementById('^' + ref).className = "layicon";
                else
                    document.getElementById('^' + ref).className = "layon"; // layon
                //                var id = parObj.id;
                //                jQuery("li[@name=" + id + "]").addClass("layicon");
                if (lev == 2)
                    document.getElementById('jQuery' + indexString).className = "layicon";
                else if (lev == 3) {
                    document.getElementById('jQuery' + parObj.parObj).className = "layicon";
                    document.getElementById(parObj.tid).className = "layon";
                }
            }
            else {

                if (lev == 2) {
                    if (!(this._curItems.GetFather({ id: parObj.id, name: null, parObj: null })))
                        document.getElementById('jQuery' + indexString).className = "layshow";
                    if (parItem.subItems[ref].subItems && parItem.subItems[ref].subItems.length > 1)
                        document.getElementById('^' + ref).className = "";
                    else
                        document.getElementById('^' + ref).className = "nonelay";
                }
                else if (lev == 3) {
                    var flag = false;
                    var tmpdata = this.allItems[this._type]()[parObj.parObj].subItems;
                    for (var i = 0; i < tmpdata.length; i++) {
                        for (var m = 0; m < this._curItems.length; m++) {
                            if (this._curItems[m].id != null && this._curItems[m].id == tmpdata[i].id) flag = true;
                            if (this._curItems[m].parObj != null && this._curItems[m].parObj.id == tmpdata[i].id) flag = true;
                        }
                    }
                    if (flag == false) document.getElementById('jQuery' + parObj.parObj).className = "layshow";
                    if (!(this._curItems.GetFather({ id: parObj.id, name: null, parObj: null }))) {
                        document.getElementById('^' + ref).className = "layshow";
                    }
                    document.getElementById(parObj.tid).className = "nonelay";
                }
            }
            if (lev == "2") {
                jQuery("#thirdItems input").each(function(i) { this.checked = this.disabled = cbx.checked; });
                if (cbx.checked) {
                    jQuery("#thirdItems li").each(function(i) { this.className = "layon"; });
                }
                else {
                    jQuery("#thirdItems li").each(function(i) { this.className = "nonelay"; });
                }
            }
        }

    },
    showtips: function() {
        if (this._curItems.length == 0) {
            if (this._type != "ind")
                jQuery("#divSelecting").css("display", "none");
            if (this._type == "cat") {
                //jQuery("#allItems1 li").each(function(i) { if(this.className =="layicon")this.className="";if(this.className =="layon")this.className="nonelay"; });
                jQuery("#noSelectedLoc").hide();
                if (this.InSalaryPage) {
                    jQuery("#noSelectedCat p").html(jQuery("#noSelectedCat p").html().replace("��������ѡ��5��ְλ���", "&nbsp;"));
                }
                jQuery("#noSelectedCat").show();
            }
            if (this._type == "loc") {
                //jQuery("#allItems1 li").each(function(i) { if(this.className =="layicon")this.className="";if(this.className =="layon")this.className="nonelay"; });
                jQuery("#noSelectedCat").hide();
                if (this.InSalaryPage) {
                    jQuery("#noSelectedLoc p").html(jQuery("#noSelectedLoc p").html().replace("��������ѡ��5�������ص�", ""));
                }
                jQuery("#noSelectedLoc").show();
            }

        }
    },

    remove: function(id, parObj, index) {
        document.getElementById("selecting").removeChild(document.getElementById(id));
        var pcbx = document.getElementById("pcbx" + id);
        if (pcbx) pcbx.checked = false;
        var array = this._curItems.clone();
        this._curItems.clear();
        for (var i = 0; i < array.length; i++) {
            if (array[i].id != id) this._curItems.push(array[i]);
        }

        if (parObj == null) {
            jQuery("li[@name=" + id + "]").removeClass("layicon");
            jQuery("li[@name=" + id + "]").removeClass("layon");
            for (var i = 32; i < this.allItems[this._type]().length; i++) {

                if (this.allItems[this._type]()[i].id == id && this.allItems[this._type]()[i].subItems.length <= 1) {
                    jQuery("li[@name=" + id + "]").addClass("nonelay");
                    break;
                }
            }
        }
        else {
            var flag = false;
            if (index != undefined) {
                var tmpdata = this.allItems[this._type]()[index].subItems;
                for (var i = 0; i < tmpdata.length; i++) {
                    for (var m = 0; m < this._curItems.length; m++) {
                        if (this._curItems[m].id != null && this._curItems[m].id == tmpdata[i].id) flag = true;
                        if (this._curItems[m].parObj != null && this._curItems[m].parObj.id == tmpdata[i].id) flag = true;
                    }
                }
            }
            if (flag == false)
                if (!(this._curItems.GetFather({ id: parObj, name: null, parObj: null })) && !(this._curItems.GetFaFather({ id: parObj, name: null, parObj: null })))
                jQuery("li[@name=" + parObj + "]").removeClass("layicon");
        }
        var temp = jQuery("#allItems1 li[@name=" + id + "]");
        if (temp.length > 0) {
            var pcbxAll = document.getElementById("pcbx999999");
            if (pcbxAll != null && pcbxAll.checked) {
                jQuery("#allItems1 input").each(function(i) { this.disabled = false; });
                pcbxAll.checked = false;
                jQuery("li[@name=999999]").attr("class", "nonelay");
            }
        }
        PopupSelector.showtips();
        //this.showHideSelecting(this);
    },
    removelv3: function(id, parObj, fname, index) {
        document.getElementById("selecting").removeChild(document.getElementById(id));
        var pcbx = document.getElementById("pcbx" + id);
        if (pcbx) pcbx.checked = false;
        var array = this._curItems.clone();
        this._curItems.clear();
        for (var i = 0; i < array.length; i++) {
            if (array[i].id != id) this._curItems.push(array[i]);
        }
        if (parObj == null) {
            jQuery("li[@name=" + id + "]").removeClass("layicon");
            jQuery("li[@name=" + id + "]").removeClass("layon");
        }
        else {
            var flag = false;
            var tmpdata = this.allItems[this._type]()[index].subItems;
            for (var i = 0; i < tmpdata.length; i++) {
                for (var m = 0; m < this._curItems.length; m++) {
                    if (this._curItems[m].id != null && this._curItems[m].id == tmpdata[i].id) flag = true;
                    if (this._curItems[m].parObj != null && this._curItems[m].parObj.id == tmpdata[i].id) flag = true;
                }
            }
            if (flag == false)
                jQuery("li[@name=" + fname + "]").removeClass("layicon");
        }
        PopupSelector.showtips();
        //this.showHideSelecting(this);
    },

    //private method
    showHideSelecting: function(selector) {
        jQuery("#noSelectedCat").hide();
        jQuery("#noSelectedLoc").hide();

        if (selector._curItems.length > 0) {
            jQuery("#divSelecting").show();
        }
        //        else {
        //            if (selector._type != "ind") jQuery("#divSelecting").hide();
        //            if (selector._type == "cat") jQuery("#noSelectedCat").show();
        //            else if (selector._type == "loc") jQuery("#noSelectedLoc").show();
        //        }
    },

    showSubItems: function(index, firstid, ref, isDelay, ev) {
        var subItems = jQuery("#subItems");
        if (this._hideTimer) clearTimeout(this._hideTimer);
        if (this._showTimer) clearTimeout(this._showTimer);
        if (index == this._lastPopupIndex && subItems.css("display") == "block") {
            jQuery(ref).addClass("layshow");
            return;
        }
        if (!isDelay) loadSubItems(index, ref, this);
        var self = this;
        this._showTimer = setTimeout(function() { loadSubItems(index, ref, self); }, this._delay);

        function loadSubItems(index, ref, self) {
            var parItem = self.allItems[self._type]()[index];
            var offset = jQuery(ref).offset();
            var pos = { top: offset.top + self._style.offset.levelTwo[self._type].Y, left: offset.left + self._style.offset.levelTwo[self._type].X };
            if (document.body.clientWidth < pos.left + 296) {
                pos.left = offset.left - 296;
            }
            var actualSubItemCount = parItem.subItems.length - 1;
            var calItemCount = (actualSubItemCount % 2 == 0) ? actualSubItemCount / 2 : (actualSubItemCount / 2 + 1);
            if (actualSubItemCount <= self._oneColumnLimit[self._type]) calItemCount = actualSubItemCount;
            var subBoxHeight = self._style.lineHeight * parseInt(calItemCount) + self._style.topBottomMargin;
            var winHeight = jQuery(window).height();
            var scrolTop;
            //if (jQuery.browser.msie && jQuery.browser.version == '6.0') scrolTop = document.body.scrollTop;
            if (jQuery.browser.msie || jQuery.browser.mozilla) scrolTop = document.body.scrollTop;
            else scrolTop = document.documentElement.scrollTop;
            var remainHeight = winHeight - pos.top + scrolTop;
            if (remainHeight < subBoxHeight) pos.top = pos.top - (subBoxHeight - remainHeight);
            //�������IE���ڵĸ߶�С�ڵ�����ĸ߶ȣ��򵯳����Զ��붥����ʾ
            if (subBoxHeight > winHeight) pos.top = scrolTop;

            var parentChecked = (ref.getElementsByTagName("input")[0].checked == true) ? " checked disabled " : "";
            var item = { id: parItem.id, name: parItem.name, parObj: null };
            var html = [];
            html.push("<ol >");
            var startIndex = 1; //��Ϊְ�������ĵ�һ���Ǹ�������ְλ�������� ����Ӧ�ðѵ�һ��������˵�

            if (self._type == "loc") {
                startIndex = 0;
            }
            for (var i = startIndex; i < parItem.subItems.length; i++) {
                var subItem = parItem.subItems[i];
                subItem.parObj = item;
                if (ref.getElementsByTagName("input")[0].checked == true || self._curItems.has(subItem) || self._curItems.GetFather(subItem)) {
                    if (parItem.subItems[i].subItems && parItem.subItems[i].subItems.length > 0) {
                        html.push("<li id=^" + i + " name=" + parItem.id + "  class=\"layicon\"  onmouseover=\"PopupSelector.showThirdItems(");
                        html.push(index);
                        html.push(",")
                        html.push(i);
                        html.push(", this, true)\" onmouseout=\"PopupSelector.hideThirdItems(this)\">");
                        html.push("<a href=\"javascript:void(0);\">");
                        html.push("<input id=\"scbx");
                        html.push(subItem.id);
                        html.push("\" type=\"" + PopupSelector._checkType + "\" value=\"");
                        html.push(subItem.id);
                        html.push("@");
                        html.push(subItem.name);
                        html.push("\"");
                        html.push(parentChecked);
                        if (self._curItems.has(subItem)) html.push(" checked");
                        html.push(" onclick=\"PopupSelector.click(" + i + ",this, { id: ");
                        html.push(parItem.id);
                        html.push(", name: '");
                        html.push(parItem.name);
                        html.push("', parObj: " + index + " }");
                        //html.push("', parObj:null }");
                        //html.push(",'')\" />");
                        html.push(",'','2')\" />");
                        html.push(dbcToSbc(subItem.name));
                        html.push("</a></li>");
                    } else {
                        html.push("<li id=^" + i + " name=" + parItem.id + " class=\"layon\" onmouseover='PopupSelector.clearThirdHidden()' onmouseover='PopupSelector.hideThirdItems(this)'>");
                        html.push("<a href=\"javascript:void(0);\"><label for=\"scbx");
                        html.push(subItem.id);
                        html.push("\">");
                        html.push("<input id=\"scbx");
                        html.push(subItem.id);
                        html.push("\" type=\"" + PopupSelector._checkType + "\" value=\"");
                        html.push(subItem.id);
                        html.push("@");
                        html.push(subItem.name);
                        html.push("\"");
                        html.push(parentChecked);
                        if (self._curItems.has(subItem)) html.push(" checked");
                        html.push(" onclick=\"PopupSelector.click(" + i + ",this, { id: ");
                        html.push(parItem.id);
                        html.push(", name: '");
                        html.push(parItem.name);
                        html.push("', parObj: " + index + " }");
                        //html.push("', parObj:null }");
                        //html.push(",'')\" />");
                        html.push(",'','2')\" />");
                        html.push(dbcToSbc(subItem.name));
                        html.push("</label></a></li>");
                    }
                } else {
                    if (parItem.subItems[i].subItems && parItem.subItems[i].subItems.length > 0) {
                        html.push("<li id=^" + i + " name=" + parItem.id + " onmouseover=\"PopupSelector.showThirdItems(");
                        html.push(index);
                        html.push(",")
                        html.push(i);
                        html.push(", this, true)\" onmouseout=\"PopupSelector.hideThirdItems(this)\">");
                        html.push("<a href=\"javascript:void(0);\">");
                        html.push("<input id=\"scbx");
                        html.push(subItem.id);
                        html.push("\" type=\"" + PopupSelector._checkType + "\" value=\"");
                        html.push(subItem.id);
                        html.push("@");
                        html.push(subItem.name);
                        html.push("\"");
                        html.push(parentChecked);
                        if (self._curItems.has(subItem)) html.push(" checked");
                        html.push(" onclick=\"PopupSelector.click(" + i + ",this, { id: ");
                        html.push(parItem.id);
                        html.push(", name: '");
                        html.push(parItem.name);
                        html.push("', parObj: " + index + " }");
                        //html.push("', parObj:null }");
                        //html.push(",'')\" />");
                        html.push(",'','2')\" />");
                        html.push(dbcToSbc(subItem.name));
                        html.push("</a></li>");
                    }
                    else {
                        html.push("<li id=^" + i + " name=" + parItem.id + " class=\"nonelay\" onmouseover='PopupSelector.clearThirdHidden()' onmouseover='PopupSelector.hideThirdItems(this)'>");
                        html.push("<a href=\"javascript:void(0);\"><label for=\"scbx");
                        html.push(subItem.id);
                        html.push("\">");
                        html.push("<input id=\"scbx");
                        html.push(subItem.id);
                        html.push("\" type=\"" + PopupSelector._checkType + "\" value=\"");
                        html.push(subItem.id);
                        html.push("@");
                        html.push(subItem.name);
                        html.push("\"");
                        html.push(parentChecked);
                        if (self._curItems.has(subItem)) html.push(" checked");
                        html.push(" onclick=\"PopupSelector.click(" + i + ",this, { id: ");
                        html.push(parItem.id);
                        html.push(", name: '");
                        html.push(parItem.name);
                        html.push("', parObj: " + index + " }");
                        //html.push("', parObj:null }");
                        //html.push(",'')\" />");
                        html.push(",'','2')\" />");
                        html.push(dbcToSbc(subItem.name));
                        html.push("</label></a></li>");
                    }
                }


                //                html.push("<a href=\"javascript:void(0);\"><label for=\"scbx");
                //                html.push(subItem.id);
                //                html.push("\">

            }
            html.push("</ol>");
            var subBox = jQuery("#subBox");
            for (var i = 0; i < self._types.length; i++) {
                subItems.removeClass(self._style.className.levelTwo1[self._types[i]]);
                subItems.removeClass(self._style.className.levelTwo2[self._types[i]]);
            }
            var levelTwo = (actualSubItemCount > self._oneColumnLimit[self._type]) ? self._style.className.levelTwo2[self._type] : self._style.className.levelTwo1[self._type];
            if (self._type == "loc") {
                if (parItem.id == "8000" || parItem.id == "15000") {
                    levelTwo = self._style.className.levelTwo1[self._type];
                }
            }
            self._lastPopupIndex = index;
            jQuery("#subItems").hover(function(e) { self.showSubItems(index, firstid, ref, true, e); }, function(e) { self.hideSubItems(ref); });
            subBox.html(html.join(""));
            subItems.addClass(levelTwo).css(pos).show();
        }
    },

    hideSubItems: function(ref) {
        jQuery(ref).removeClass("layshow");
        if (this._showTimer) clearTimeout(this._showTimer);
        if (this._hideTimer) clearTimeout(this._hideTimer);
        this._hideTimer = setTimeout(function() { jQuery("#subItems").hide(); }, 100);
    },
    clearThirdHidden: function() {
        if (this._showThirdTimer) clearTimeout(this._showThirdTimer);
        if (this._hideThirdTimer) clearTimeout(this._hideThirdTimer);
        jQuery("#thirdItems").hide();
    },
    showThirdItems: function(index, secondIndex, ref, isDelay, ev) {

        var subItems = jQuery("#thirdItems");
        //                if (this._hideTimer) clearTimeout(this._hideTimer);
        //                if (this._showTimer) clearTimeout(this._showTimer);

        if (this._showThirdTimer) clearTimeout(this._showThirdTimer);
        if (this._hideThirdTimer) clearTimeout(this._hideThirdTimer);

        //jQuery("#debugInfo").html("index: " + index + " secondIndex:" + secondIndex + " this._lastPopupIndex: " + this._lastPopupIndex);
        //        if (index == this._lastPopupIndex && subItems.css("display") == "block") {
        //            jQuery(ref).addClass("layshow");
        //            return;
        //        }
        if ((secondIndex + 50) == this._lastPopupIndex && subItems.css("display") == "block") {
            jQuery("#jQuery" + index).addClass("layshow"); jQuery(ref).addClass("layshow");
            return;
        }
        if (!isDelay) loadThirdItems(index, secondIndex, ref, this);
        var self = this;
        this._showThirdTimer = setTimeout(function() { loadThirdItems(index, secondIndex, ref, self); }, this._delay);

        function loadThirdItems(index, secondIndex, ref, self) {


            //var parItem = self.allItems[self._type]()[index];
            var parItem = self.allItems[self._type]()[index].subItems[secondIndex];
            var offset = jQuery(ref).offset();
            var pos = {
                top: offset.top + self._style.offset.levelTwo[self._type].Y,
                left: offset.left + self._style.offset.levelTwo[self._type].X
            };
            if (document.body.clientWidth < pos.left + 296) {
                pos.left = offset.left - 296;
            }
            var actualSubItemCount = parItem.subItems.length - 1;
            var calItemCount = (actualSubItemCount % 2 == 0) ? actualSubItemCount / 2 : (actualSubItemCount / 2 + 1);
            if (actualSubItemCount <= self._oneColumnLimit[self._type]) calItemCount = actualSubItemCount;
            var subBoxHeight = self._style.lineHeight * parseInt(calItemCount) + self._style.topBottomMargin;
            var winHeight = jQuery(window).height();
            var scrolTop;
            if (jQuery.browser.msie || jQuery.browser.mozilla) scrolTop = document.body.scrollTop;
            else scrolTop = document.documentElement.scrollTop;
            var remainHeight = winHeight - pos.top + scrolTop;
            if (remainHeight < subBoxHeight) pos.top = pos.top - (subBoxHeight - remainHeight);
            if (subBoxHeight > winHeight) pos.top = scrolTop;
            var parentChecked = (ref.getElementsByTagName("input")[0].checked == true) ? " checked disabled " : "";
            var item = {
                id: parItem.id,
                name: parItem.name,
                parObj: null
            };
            var html = [];
            html.push("<ol >");
            for (var i = 0; i < parItem.subItems.length; i++) {
                var subItem = parItem.subItems[i];
                subItem.parObj = item;
                //                if (ref.getElementsByTagName("input")[0].checked == true || self._curItems.has(subItem)) {
                //                    html.push("<li id=Q" + i + " class=\"nonelay\"  >");
                //                }
                //                else
                if (ref.getElementsByTagName("input")[0].checked == true || self._curItems.has(subItem)) {
                    html.push("<li id=Q" + i + " class=\"layon\"  >");
                }
                else {
                    html.push("<li id=Q" + i + " class=\"nonelay\"  >");
                }
                html.push("<a href=\"javascript:void(0);\"><label for=\"tcbx");
                html.push(subItem.id);
                html.push("\"><input id=\"tcbx");
                html.push(subItem.id);
                html.push("\" type=\"checkbox\" value=\"");
                html.push(subItem.id);
                html.push("@");
                html.push(subItem.name);
                html.push("\"");
                html.push(parentChecked);
                if (self._curItems.has(subItem)) html.push(" checked");
                html.push(" onclick=\"PopupSelector.click(" + secondIndex + ",this, { id: ");
                html.push(parItem.id);
                html.push(", name: '");
                html.push(parItem.name);
                html.push("', parObj:  " + index + ",tid:'Q" + i + "'}");
                html.push(",'','3')\" />");
                html.push(addSpan(subItem.name));
                html.push("</label></a></li>");
            }
            html.push("</ol>");
            var subBox = jQuery("#thirdBox");
            for (var i = 0; i < self._types.length; i++) {
                //subItems.removeClass(self._style.className.levelTwo1[self._types[i]]);
                //subItems.removeClass(self._style.className.levelTwo2[self._types[i]]);
                subItems.removeClass(self._style.className.levelThree1[self._types[i]]);
                subItems.removeClass(self._style.className.levelThree2[self._types[i]]);
            }
            //var levelTwo = (actualSubItemCount > self._oneColumnLimit[self._type]) ? self._style.className.levelTwo2[self._type] : self._style.className.levelTwo1[self._type];
            var levelTwo = (actualSubItemCount > self._oneColumnLimit[self._type]) ? self._style.className.levelThree2[self._type] : self._style.className.levelThree1[self._type];
            if (self._type == "loc") {
                if (parItem.id == "8000" || parItem.id == "15000") {
                    //levelTwo = self._style.className.levelTwo1[self._type];
                    levelTwo = self._style.className.levelThree1[self._type];
                }
            }
            self._lastPopupIndex = secondIndex + 50;
            //jQuery("#thirdItems").hover(function(e) { self.showSubItems(index, ref, true, e); }, function(e) { self.hideSubItems(ref); });
            jQuery("#thirdItems").hover(
                function(e) {
                    //alert(self.thirdHoverIn());
                    // debugger;
                    if (self._hideTimer) clearTimeout(self._hideTimer);
                    if (self._hideThirdTimer) clearTimeout(self._hideThirdTimer);
                    //self.showThirdItems(index, secondIndex, ref, isDelay, ev);
                    self.showThirdItems(index, secondIndex, ref, true, e);
                },
                function(e) {
                    ; //if (self._hideTimer) clearTimeout(self._hideTimer);
                    self.hideThirdItems();
                }
            );

            subBox.html(html.join(""));
            subItems.css("display", "block");
            subItems.addClass(levelTwo).css(pos).show();
            //debugger;
        };
        //loadSubItems end
    },
    hideThirdItems: function(ref) {
        jQuery(ref).removeClass("layshow");

        if (this._showTimer) clearTimeout(this._showTimer);
        if (this._hideTimer) clearTimeout(this._hideTimer);

        if (this._showThirdTimer) clearTimeout(this._showThirdTimer);
        if (this._hideThirdTimer) clearTimeout(this._hideThirdTimer);



        this._hideThirdTimer = setTimeout(function() {
            jQuery("#thirdItems").hide();
            jQuery("#subItems").hide();
        }, 100);
    },
    _showTimer: null,
    _hideTimer: null,
    _showThirdTimer: null,
    _hideThirdTimer: null,
    _lastPopupIndex: null,
    _box: null,
    _subbox: null,
    _ref: null,
    _type: null,
    _types: ["cat", "ind", "loc", "comptype"],
    _maxSize: 5,
    _checkType: "checkbox",

    //_curItems���ڵ�������ʾʱ���û����ӻ���ٵ�ѡ��������������û����ʱ��Ҳ����մ����飬
    //�����ȷ��ʱ�����������е�ѡ��Ƶ�_selItems�ж�Ӧ���������־ñ��棬Ȼ����մ�����
    //ʾ����[{id:xxx, name:xxxx, parObj:null/object ref, isParent:true/false}, .....]
    _curItems: [],
    _selItems: { cat: [], loc: [], ind: [], comptype: [] },

    _gtMaxLimit: "�Բ���,������ѡ���Ѿ��ﵽ��3��.�������ѡ��,�ټ���ѡ��",
    _gtYourSelected: { cat: "��ѡ���ְλ����ǣ�", ind: "��������ѡ�񣵸���ҵ���", loc: "��ѡ��ĵ�����", comptype: "��ѡ��Ĺ�˾�����ǣ�" },
    _gtPopupSelectorHeader: { cat: "ְλ���", ind: "��ҵ���", loc: "��ѡ�����", comptype: "��˾����" },
    _oneColumnLimit: { cat: 12, loc: 11 }, //���������ʾ��һ�е������Ŀ���������������Ҫ��ʾ������
    _delay: 500,
    _style: {
        className: {
            levelOne: { "cat": "lay_wl", "loc": "lay_wls", "ind": "lay_wll", "comptype": "lay_wms" },
            //�������һ����ʾ����ʽ
            levelTwo1: { "cat": "lay_wm", "loc": "lay_ws lm", "ind": "", "comptype": "" },
            //�������������ʾ����ʽ
            levelTwo2: { "cat": "lay_wl2", "loc": "lay_ws lm", "ind": "", "comptype": "" },
            //�������һ����ʾ����ʽ
            levelThree1: { "cat": "lay_wm", "loc": "lay_ws", "ind": "", "comptype": "" },
            //3�����������ʾ����ʽ
            levelThree2: { "cat": "lay_wl2", "loc": "lay_ws", "ind": "", "comptype": "" }
        },
        left: 0,
        top: 0,
        width: { "cat": 594, "loc": 466, "ind": 746, "comptype": 360 },
        height: { "cat": 517, "loc": 419, "ind": 510, "comptype": 173 },
        lineHeight: 20,
        topBottomMargin: 17,
        offset: {
            levelOne: { X: 0, Y: 20, "cat": { X: 0, Y: 20 }, "loc": { X: 250, Y: 20} },
            levelTwo: { "cat": { X: 304, Y: 0 }, "loc": { X: 130, Y: 0} }
        }
    },
    allItems: {
        cat: function() { return getCat(); },
        ind: function() { return getInd(); },
        loc: function() { return getLoc(); },
        comptype: function() { return getCompanyType(); }
    }
};

jQuery(document).ready(function() {
    if (typeof PopCheckType_Cat != "undefined" && PopCheckType_Cat != null) {
        jQuery("#txtCat").click(function() { PopupSelector.popup("cat", this, PopCheckType_Cat); });
        jQuery("#txtInd").click(function() { PopupSelector.popup("ind", this, PopCheckType_Ind); });
        jQuery("#txtLoc").click(function() { PopupSelector.popup("loc", this, PopCheckType_Loc); });

        jQuery("#txtCatDrop").click(function() { PopupSelector.popup("cat", jQuery("#txtCat")[0], PopCheckType_Cat); });
        jQuery("#txtIndDrop").click(function() { PopupSelector.popup("ind", jQuery("#txtInd")[0], PopCheckType_Ind); });
        jQuery("#txtLocDrop").click(function() { PopupSelector.popup("loc", jQuery("#txtLoc")[0], PopCheckType_Loc); });
    }
    else {
        jQuery("#txtCat").click(function() { PopupSelector.popup("cat", this); });
        jQuery("#txtInd").click(function() { PopupSelector.popup("ind", this); });
        jQuery("#txtLoc").click(function() { PopupSelector.popup("loc", this); });
        jQuery("#txtCatDrop").click(function() { PopupSelector.popup("cat", jQuery("#txtCat")[0]); });
        jQuery("#txtIndDrop").click(function() { PopupSelector.popup("ind", jQuery("#txtInd")[0]); });
        jQuery("#txtLocDrop").click(function() { PopupSelector.popup("loc", jQuery("#txtLoc")[0]); });
    }

    popupLayer = $(".sech_layb");
    jQuery("#lnkEmpty").click(function() { PopupSelector.empty(); });
    jQuery("#lnkCancel").click(function() { PopupSelector.cancel(); });
    jQuery("#lnkOK").click(function() { PopupSelector.OK(); });
    jQuery("#btnOk").click(function() { PopupSelector.OK(); });
    jQuery("#btnOkLoc").click(function() { PopupSelector.OK(); });
    jQuery("#imgClose").click(function() { PopupSelector.close(); });

});

//�ֵ���Դ
//********************************************************************
function getJobType() {
}

function getPostDate() {

}

function getWorkExp() {

}

function getCompanyType() {

}

function getCompanySize() {

}

function getDegree() {
  
}

function getSalary() {

}

function getCat() {
}

function getLoc() {
	return [
        {
        id: "30000",
        name: "�㶫ʡ",
        subItems: [
               {
			    id: "4",
			    name: "÷����",
			    subItems: [
				{
				    id: "1614001",
				    name: "÷����"
				},
				{
				    id: "6",
				    name: "������"
				},
				{
				    id: "1614002",
				    name: "������"
				},
				{
				    id: "1614004",
				    name: "÷��"
				},
				{
				    id: "1614005",
				    name: "������"
				},
				{
				    id: "1614006",
				    name: "��˳��"
				},
				{
				    id: "7",
				    name: "�廪��"
				},
				{
				    id: "1614008",
				    name: "ƽԶ��"
				}
				]
				},
				{
    		    id: "40",
    		    name: "������",
    		    subItems: [
    			{
    			    id: "4001",
    			    name: "Խ����"
    			},
    			{
    			    id: "4002",
    			    name: "������"
    			},
    			{
    			    id: "4003",
    			    name: "������"
    			},
    			{
    			    id: "4004",
    			    name: "��ɳ��"
    			},
    			{
    			    id: "4005",
    			    name: "������"
    			},
    			{
    			    id: "4006",
    			    name: "�ܸ���"
    			},
    			{
    			    id: "4007",
    			    name: "�����"
    			},
    			{
    			    id: "4009",
    			    name: "������"
    			},
    			{
    			    id: "4011",
    			    name: "������"
    			},
    			{
    			    id: "4012",
    			    name: "��خ��"
    			},
    			{
    			    id: "4008",
    			    name: "������"
    			},
    			{
    			    id: "4013",
    			    name: "�ӻ���"
    			}
    		]
    		},
    		{
    		    id: "16130",
    		    name: "��Դ��",
    		    subItems: [
    			{
    			    id: "1613001",
    			    name: "Դ����"
    			},
    			{
    			    id: "1613002",
    			    name: "�Ͻ���"
    			},
    			{
    			    id: "1613003",
    			    name: "������"
    			},
    			{
    			    id: "1613004",
    			    name: "��ƽ��"
    			},
    			{
    			    id: "1613005",
    			    name: "��ƽ��"
    			},
    			{
    			    id: "1613006",
    			    name: "��Դ��"
    			}
    		]
    		},
    		{
    		    id: "16010",
    		    name: "������",
    		    subItems: [
    			{
    			    id: "1601001",
    			    name: "������"
    			},
    			{
    			    id: "1601002",
    			    name: "������"
    			},
    			{
    			    id: "1601003",
    			    name: "��ƽ��"
    			}
    		]
    		},
    			{
    			    id: "225",
    			    name: "��ݸ��"
    			},
    		{
    		    id: "16050",
    		    name: "��ɽ��",
    		    subItems: [
    			{
    			    id: "1605001",
    			    name: "������"
    			},
    			{
    			    id: "1605002",
    			    name: "�Ϻ���"
    			},
    			{
    			    id: "1605003",
    			    name: "��ˮ��"
    			},
    			{
    			    id: "1605004",
    			    name: "������"
    			},
    			{
    			    id: "16040",
    			    name: "˳����"
    			}
    		]
    		},
    		{
    		    id: "16020",
    		    name: "������",
    		    subItems: [
    			{
    			    id: "1602001",
    			    name: "�ݳ���"
    			},
    			{
    			    id: "1602002",
    			    name: "������"
    			},
    			{
    			    id: "1602003",
    			    name: "������"
    			},
    			{
    			    id: "1602004",
    			    name: "�ݶ���"
    			},
    			{
    			    id: "1602005",
    			    name: "������"
    			}
    		]
    		},
    		{
    		    id: "16030",
    		    name: "��Զ��",
    		    subItems: [
    			{
    			    id: "1603001",
    			    name: "�����"
    			},
    			{
    			    id: "1603003",
    			    name: "Ӣ����"
    			},
    			{
    			    id: "1603004",
    			    name: "������"
    			},
    			{
    			    id: "1603002",
    			    name: "������"
    			},
    			{
    			    id: "1603005",
    			    name: "�����"
    			},
    			{
    			    id: "1603006",
    			    name: "��ɽ��"
    			},
    			{
    			    id: "1603007",
    			    name: "������"
    			},
    			{
    			    id: "1603008",
    			    name: "��ɽ��"
    			}
    		]
    		},
    		{
    		    id: "117",
    		    name: "��ͷ��",
    		    subItems: [
    			{
    			    id: "11701",
    			    name: "��ƽ��"
    			},
    			{
    			    id: "11702",
    			    name: "������"
    			},
    			{
    			    id: "11703",
    			    name: "婽���"
    			},
    			{
    			    id: "11704",
    			    name: "������"
    			},
    			{
    			    id: "11705",
    			    name: "������"
    			},
    			{
    			    id: "11706",
    			    name: "�κ���"
    			},
    			{
    			    id: "11707",
    			    name: "�ϰ���"
    			}
    		]
    		},
    		{
    		    id: "125",
    		    name: "������",
    		    subItems: [
    			{
    			    id: "12501",
    			    name: "������"
    			},
    			{
    			    id: "12502",
    			    name: "�޺���"
    			},
    			{
    			    id: "12503",
    			    name: "��ɽ��"
    			},
    			{
    			    id: "12504",
    			    name: "������"
    			},
    			{
    			    id: "12505",
    			    name: "������"
    			},
    			{
    			    id: "12506",
    			    name: "������"
    			}
    		]
    		},
    		{
    		    id: "16060",
    		    name: "տ����",
    		    subItems: [
    			{
    			    id: "1606001",
    			    name: "�࿲��"
    			},
    			{
    			    id: "1606003",
    			    name: "ϼɽ��"
    			},
    			{
    			    id: "1606005",
    			    name: "��ͷ��"
    			},
    			{
    			    id: "1606006",
    			    name: "������"
    			},
    			{
    			    id: "1606007",
    			    name: "������"
    			},
    			{
    			    id: "1606008",
    			    name: "������"
    			},
    			{
    			    id: "1606009",
    			    name: "�⴨��"
    			},
    			{
    			    id: "1606002",
    			    name: "��Ϫ��"
    			},
    			{
    			    id: "1606004",
    			    name: "������"
    			}
    		]
    		},
    		{
    		    id: "16080",
    		    name: "������",
    		    subItems: [
    			{
    			    id: "1608001",
    			    name: "������"
    			},
    			{
    			    id: "1608003",
    			    name: "������"
    			},
    			{
    			    id: "1608004",
    			    name: "��Ҫ��"
    			},
    			{
    			    id: "1608005",
    			    name: "�Ļ���"
    			},
    			{
    			    id: "1608002",
    			    name: "������"
    			},
    			{
    			    id: "1608006",
    			    name: "������"
    			},
    			{
    			    id: "1608007",
    			    name: "������"
    			},
    			{
    			    id: "1608008",
    			    name: "�⿪��"
    			}
    		]
    		},
    			{
    			    id: "16070",
    			    name: "��ɽ��"
    			},
    		{
    		    id: "180",
    		    name: "�麣��",
    		    subItems: [
    			{
    			    id: "18001",
    			    name: "������"
    			},
    			{
    			    id: "18002",
    			    name: "������"
    			},
    			{
    			    id: "18003",
    			    name: "������"
    			}
    		]
    		},
    		{
    		    id: "16090",
    		    name: "������",
    		    subItems: [
    			{
    			    id: "1609001",
    			    name: "������"
    			},
    			{
    			    id: "1609002",
    			    name: "���"
    			},
    			{
    			    id: "1609003",
    			    name: "�»���"
    			},
    			{
    			    id: "1609004",
    			    name: "̨ɽ��"
    			},
    			{
    			    id: "1609005",
    			    name: "��ɽ��"
    			},
    			{
    			    id: "1609006",
    			    name: "��ƽ��"
    			},
    			{
    			    id: "16150",
    			    name: "��ƽ��"
    			}
    		]
    		},
    		{
    		    id: "16100",
    		    name: "��β��",
    		    subItems: [
    			{
    			    id: "1610001",
    			    name: "��β����"
    			},
    			{
    			    id: "1610002",
    			    name: "½����"
    			},
    			{
    			    id: "1610003",
    			    name: "������"
    			},
    			{
    			    id: "1610004",
    			    name: "½����"
    			}
    		]
    		},
    		{
    		    id: "16110",
    		    name: "�ع���",
    		    subItems: [
    			{
    			    id: "1611001",
    			    name: "䥽���"
    			},
    			{
    			    id: "1611003",
    			    name: "�佭��"
    			},
    			{
    			    id: "1611005",
    			    name: "������"
    			},
    			{
    			    id: "1611007",
    			    name: "�ֲ���"
    			},
    			{
    			    id: "1611008",
    			    name: "������"
    			},
    			{
    			    id: "1611002",
    			    name: "��Դ��"
    			},
    			{
    			    id: "1611004",
    			    name: "�·���"
    			},
    			{
    			    id: "1611006",
    			    name: "��Դ��"
    			},
    			{
    			    id: "1611009",
    			    name: "ʼ����"
    			},
    			{
    			    id: "1611010",
    			    name: "�ʻ���"
    			}
    		]
    		},
    		{
    		    id: "16120",
    		    name: "ï����",
    		    subItems: [
    			{
    			    id: "1612001",
    			    name: "ï����"
    			},
    			{
    			    id: "1612002",
    			    name: "ï����"
    			},
    			{
    			    id: "1612003",
    			    name: "������"
    			},
    			{
    			    id: "1612004",
    			    name: "������"
    			},
    			{
    			    id: "1612005",
    			    name: "������"
    			},
    			{
    			    id: "1612006",
    			    name: "�����"
    			}
    		]
    		},
    		{
    		    id: "16160",
    		    name: "������",
    		    subItems: [
    			{
    			    id: "1616001",
    			    name: "������"
    			},
    			{
    			    id: "1616002",
    			    name: "������"
    			},
    			{
    			    id: "1616003",
    			    name: "������"
    			},
    			{
    			    id: "1616004",
    			    name: "������"
    			}
    		]
    		},
    		{
    		    id: "16170",
    		    name: "������",
    		    subItems: [
    			{
    			    id: "1617001",
    			    name: "�ų���"
    			},
    			{
    			    id: "1617002",
    			    name: "������"
    			},
    			{
    			    id: "1617003",
    			    name: "�Ҷ���"
    			},
    			{
    			    id: "1617004",
    			    name: "������"
    			},
    			{
    			    id: "1617005",
    			    name: "������"
    			}
    		]
    		},
    		{
    		    id: "16180",
    		    name: "�Ƹ���",
    		    subItems: [
    			{
    			    id: "1618001",
    			    name: "�Ƴ���"
    			},
    			{
    			    id: "1618002",
    			    name: "�޶���"
    			},
    			{
    			    id: "1618003",
    			    name: "������"
    			},
    			{
    			    id: "1618004",
    			    name: "������"
    			},
    			{
    			    id: "1618005",
    			    name: "�ư���"
    			}
    		]
    		}
    	]
    },
		{
		id: "30001",
		name: "������"
		},
		{
		id: "31000",
		name: "�Ϻ���",
		subItems: [
				
		]
		},
		{
		id: "32000",
		name: "�����",
		subItems: []
		},
		{
		id: "33000",
		name: "������",
		subItems: [
		]
		},
		{
		id: "7000",
		name: "����ʡ",
		subItems: [
		]
		},
		{
		id: "8000",
		name: "�㽭ʡ"
		
		},
		{
		id: "9000",
		name: "����ʡ"
		},
		{
		id: "10000",
		name: "����ʡ",
		subItems: [
		]
		},
		{
		id: "24000",
		name: "����ʡ",
		subItems: [
		]
		},
		{
		id: "17000",
		name: "����",
		subItems: [
		]
		},
		{
		id: "20000",
		name: "����ʡ"
		
		},
		{
		id: "18000",
		name: "����ʡ",
		subItems: []
		},
		{
		id: "1000",
		name: "�ӱ�ʡ",
		subItems: [
			
		]
		},
		{
		id: "13000",
		name: "����ʡ",
		subItems: [
		]
		},
		{
		id: "6000",
		name: "������ʡ",
		subItems: [
		]
		},
		{
		id: "14000",
		name: "����ʡ",
		subItems: []
			
		
		},
		{
		id: "15000",
		name: "����ʡ",
		subItems: []
		},
		{
		id: "5000",
		name: "����ʡ",
		subItems: [
		]
		},
		{
		id: "11000",
		name: "����ʡ",
		subItems: [
		]
		},
		{
		id: "4000",
		name: "����ʡ",
		subItems: [
		]
		},
		{
		id: "3000",
		name: "���ɹ�",
		subItems: [
		]
		},
		{
		id: "26000",
		name: "����",
		subItems: [
		]
		},
		{
		id: "25000",
		name: "�ຣʡ",
		subItems: [
		]
		},
		{
		id: "12000",
		name: "ɽ��ʡ",
		subItems: [
		]
		},
		{
		id: "2000",
		name: "ɽ��ʡ",
		subItems: [
		]
		},
		{
		id: "23000",
		name: "����ʡ",
		subItems: []
		},
		{
		id: "19000",
		name: "�Ĵ�ʡ",
		subItems: [
		]
		},
		{
		id: "22000",
		name: "����",
		subItems: [
		]
		},
		{
		id: "27000",
		name: "�½�",
		subItems: [
		]
		},
		{
		id: "21000",
		name: "����ʡ",
		subItems: [
		]
		},
		{
		id: "34000",
		name: "���",
		subItems: [
		]
		},
		{
		id: "35000",
		name: "����",
		subItems: [
				{
				    id: "190",
				    name: "����"
				}
		]
		},
		{
		id: "36000",
		name: "̨��",
		subItems: [
				{
				    id: "195",
				    name: "̨��"
				}
		]
		}

		];
}

function getInd() {
    return [
        { id: "100", name: "�����", enname: "Computer" },
        { id: "3600", name: "������?��������", enname: "Internet" },
        { id: "1123000", name: "������Ϸ", enname: "Online Game" },
        { id: "300", name: "����?΢����", enname: "Electronics" },
        { id: "400", name: "ͨ��(�豸?��Ӫ?��ֵ����)", enname: "Telecommunication" },
        { id: "800", name: "���?��չ?����", enname: "advertising" },
        { id: "1100", name: "���ز�����?�����빤��", enname: "Real Estate construction" },
        { id: "3700", name: "��ҵ����?��ҵ����", enname: "Property Management" },
        { id: "1500", name: "�Ҿ�?�������?װ��", enname: "fitment" },
        { id: "2800", name: "�н����", enname: "Service Agency" },
        { id: "900", name: "רҵ����(��ѯ?�ƻ�?���ɵ�)", enname: "Professional Service" },
        { id: "1124000", name: "����?���?��֤", enname: "testing Certification" },
        { id: "1000", name: "����ҵ(Ͷ��?����?֤ȯ?����?����)", enname: "Finance" },
        { id: "700", name: "ó��?������", enname: "trading" },
        { id: "1118000", name: "ý��?����?�Ļ�����", enname: "Media Publishing" },
        { id: "2600", name: "ӡˢ?��װ?��ֽ", enname: "Printing packaging" },
        { id: "1300", name: "��������Ʒ(ʳƷ?����?�ջ�?�̾Ƶ�)", enname: "fast Consumer" },
        { id: "1113000", name: "��������Ʒ(����?��֯?Ƥ��?�Ҿ�)", enname: "Consumer Durables" },
        { id: "1125000", name: "���?����Ʒ?�ղ�Ʒ?�ݳ�Ʒ", enname: "Toys Artworks Collections" },
        { id: "1400", name: "�ҵ�ҵ", enname: "Domestic Appliances" },
        { id: "1800", name: "�칫�豸?��Ʒ", enname: "Office euqipment" },
        { id: "1600", name: "����?�Ƶ�?��������", enname: "catering" },
        { id: "600", name: "����?����", enname: "Wholesale Retail" },
        { id: "1700", name: "��ͨ?����?����", enname: "Logistics" },
        { id: "1200", name: "����?�˶�?����", enname: "Entertainment" },
        { id: "2300", name: "��ҩ?���﹤��", enname: "Pharmaceuticals Biotechnology" },
        { id: "3200", name: "ҽ��?����?����?��������", enname: "Medical service" },
        { id: "2000", name: "ҽ���豸?��е", enname: "Medical Equipment" },
        { id: "2400", name: "����", enname: "Environment protection" },
        { id: "2200", name: "ʯ��?����?���?�ɾ�?ұ��?ԭ����", enname: "Petroleum Mining Raw Meterial" },
        { id: "1122000", name: "��Դ(����?ʯ��)?ˮ��", enname: "Energy" },
        { id: "3900", name: "����?�Ǳ�?��ҵ�Զ���?����", enname: "Instrument Automation Electicity" },
        { id: "2100", name: "����?Ħ�г�(����?ά��?���?����?����)", enname: "Automobile" },
        { id: "1114000", name: "��е����?����?�ع�", enname: "Heavy industry" },
        { id: "1115000", name: "ԭ���ϼ��ӹ�(����?ľ��?��?����?����?�մ�?����)", enname: "Raw Material and processing" },
        { id: "1106000", name: "����ҵ", enname: "Service" },
        { id: "2900", name: "ũ?��?��?��", enname: "Agriculture" },
        { id: "1105000", name: "����?�����о�������", enname: "Aeronautics" },
        { id: "1126000", name: "��������", enname: "Shipbuilding" },
        { id: "3100", name: "����?��ѵ?����?ԺУ", enname: "Education Training" },
        { id: "1116000", name: "����?��Ӫ������", enname: "Government Nonprofit Organization" },
        { id: "1121000", name: "����", enname: "Others" }
    ];
}