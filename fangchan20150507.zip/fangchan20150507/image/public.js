
function loadWin(Loct,feature,focus)
{

	txtid=focus
	var features=feature+"toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes"
	window.open(Loct,"",features)
}

var beforeColor,beforeStyle;

function changeBg(obj)
{
		beforeColor=obj.bgColor;
		beforeStyle=obj.style.color
		obj.bgColor="#CBC7D0";
		obj.color="#000000"
		Ring=true
}

function rechangeBg(obj)
{
	obj.bgColor=beforeColor;
	obj.style.color=beforeStyle;
}