


function loginuser(){
if(document.getElementById("user_account").value==""){
	alert("�������˺�");
	document.getElementById("user_account").focus();
	return;
}
if(document.getElementById("user_pw").value==""){
	alert("����������");
	document.getElementById("user_pw").focus();
	return;
}
	document.forms["login1"].submit();
}

function change_pc2(curnum,showclass,num,prefix){
	for(i=1;i<=num;i++){
		if(i!=curnum){			
			document.getElementById(prefix + i).style.display = 'none';
			document.getElementById('pc2_' + i).className = 'recommend_btn2';
		}
	}
	document.getElementById(prefix + curnum).style.display = 'block';
	document.getElementById('pc2_' + curnum).className = 'recommend_btn1';
}

function searchjob(context){
	var recruitment_type=document.getElementById("keyword").value;
	var city=$("#cityIdName").val();
	var type_id = document.getElementById("type_id").value;
	var work_callname = document.getElementById("work_callname").value;
	if(recruitment_type.indexOf("or")==0){
		recruitment_type=recruitment_type.replace(/or/g,'');   
	}
	
	if(work_callname="���ֲ���"){
		work_callname="";
	}
	
	if(recruitment_type="������ؼ���"){
		recruitment_type="";
	}
	
	if (work_callname == "") {
		type_id = "";
	}
	var callname="";
	if(work_callname!=""){
		works=work_callname.split("+");
		for(i=0;i<works.length;i++){
			callname+=works[i]+":";
		}
		work_callname=callname.substring(0,callname.length-1);
	}
	window.location.href="qySearch.jsp?searchtype=1&recruitment_type="+recruitment_type+"&type_id="+type_id+"&work_callname="+work_callname+"&cityIdName="+city;
}

function selectjobtypes(url,para,msg){
	 var url;                                 //ת����ҳ�ĵ�ַ;
	  var name;                           //��ҳ���ƣ���Ϊ��;
	  var iWidth=600;                          //�������ڵĿ���;
	  var iHeight=460;                        //�������ڵĸ߶�;
	  var iTop = (window.screen.availHeight-30-iHeight)/2;       //��ô��ڵĴ�ֱλ��;
	  var iLeft = (window.screen.availWidth-10-iWidth)/2;           //��ô��ڵ�ˮƽλ��;
	  window.open(url+'?msg='+msg,name,'height='+iHeight+',,innerHeight='+iHeight+',width='+iWidth+',innerWidth='+iWidth+',top='+iTop+',left='+iLeft+',toolbar=no,menubar=no,scrollbars=auto,resizeable=no,location=no,status=no');
	return;
}