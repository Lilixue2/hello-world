function finout(bIn){
 var e=event.srcElement;
 if(e.tagName=="TD"){
  e.parentNode.style.backgroundColor= bIn?"#A5D8E0":"";
  }
}


