﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_news_type : System.Web.UI.Page
{
    private Bill bl = new Bill();
   
    private void bind()
    {

        this.DropDownList1.DataSource = this.bl.GetNewT();
        this.DropDownList1.DataValueField = "TYPEID";
        this.DropDownList1.DataTextField = "TYPENAME";
        this.DropDownList1.DataBind();
        ListItem item = new ListItem("请选择", "0");
        this.DropDownList1.Items.Insert(0, item);  

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlTransaction trans = null;
        try
        {
            trans = DB.GetConnection().BeginTransaction();

            ArrayList listParam = new ArrayList();
            String sql = "";

            sql = "INSERT INTO news_type(TypeName,ParentId) VALUES(@0,@1)";
            
            listParam.Add(TextBox1.Text);

            string a =Convert.ToString(DropDownList1.SelectedValue);
            int b;
            if (string.IsNullOrEmpty(a))
            {
                b = 0;
            }
            else
            {
                b = Convert.ToInt32(DropDownList1.SelectedValue);
            }

            listParam.Add(b);


            DB.ExecuteSQL(sql, listParam);
            
            Common.Alert("保存类别成功!", this);
            
            clearData();

            trans.Commit();
        }
        catch (Exception ex)
        {
            if (trans != null)
                trans.Rollback();

            Response.Write(ex.Message);
            Response.End();
        }
    }



    private void clearData()
    {
        TextBox1.Text = "";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.bind();
        }

    }

}
