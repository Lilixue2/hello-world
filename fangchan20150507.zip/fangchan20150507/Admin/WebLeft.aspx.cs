﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_WebLeft : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            String sql = "SELECT funcid, adminid from admin_authority where adminid=@0";
            object[] parameters = new object[1];
            parameters[0] = Session["adminid"].ToString();

            DataTable user = DB.GetDataSet(sql, parameters).Tables[0];
            for (int i=0; i < user.Rows.Count; i++)
            {
                if (user.Rows[i]["funcid"].ToString().Equals("1"))
                {
                    this.link1.Visible = true;
                    this.p1.Visible = true;
                }
                else if (user.Rows[i]["funcid"].ToString().Equals("2"))
                {
                    this.link2.Visible = true;
                    this.p2.Visible = true;
                }

                else if (user.Rows[i]["funcid"].ToString().Equals("3"))
                {
                    this.link3.Visible = true;
                    this.p3.Visible = true;
                }

                else if (user.Rows[i]["funcid"].ToString().Equals("4"))
                {
                    this.link4.Visible = true;
                    this.p4.Visible = true;
                }
            
                else if (user.Rows[i]["funcid"].ToString().Equals("5"))
                {
                    this.link5.Visible = true;
                    this.p5.Visible = true;
                }
              
                

                }
            }
        }
    }

