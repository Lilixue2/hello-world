﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Linq;
using System.Xml.Linq;

public partial class Admin_Company_Manage : System.Web.UI.Page
{
    SqlConnection sqlcon;
    SqlCommand sqlcom;
    string strCon = "Data Source=(local);Database=TFang;Uid=sa;Pwd=sa";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Response.Write("<script>window.top.navigate('Default.aspx');</script>");
            return;
        }
        if (!IsPostBack)
        {
            bind();
            loadData();
        }

    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        bind();
    }

    //删除
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string sqlstr = "delete from company_base where username='" + GridView1.DataKeys[e.RowIndex].Value.ToString() + "'";
        sqlcon = new SqlConnection(strCon);
        sqlcom = new SqlCommand(sqlstr, sqlcon);
        sqlcon.Open();
        sqlcom.ExecuteNonQuery();
        sqlcon.Close();
        bind();
    }

    //更新
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        sqlcon = new SqlConnection(strCon);
        string sqlstr = "update company_base set cperson='"
            + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[1].Controls[0])).Text.ToString().Trim() + "',cphone='"
            + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[2].Controls[0])).Text.ToString().Trim() + "', email='"
            + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[3].Controls[0])).Text.ToString().Trim() + "' ,Address='"
            + ((TextBox)(GridView1.Rows[e.RowIndex].Cells[4].Controls[0])).Text.ToString().Trim() + "' where NcId='"
            + GridView1.DataKeys[e.RowIndex].Value.ToString() + "'";
        sqlcom = new SqlCommand(sqlstr, sqlcon);
        sqlcon.Open();
        sqlcom.ExecuteNonQuery();
        sqlcon.Close();
        GridView1.EditIndex = -1;
        bind();
    }

    //取消
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        bind();
    }

    //绑定
    public void bind()
    {
        string sqlstr = "select * from company_base";
        sqlcon = new SqlConnection(strCon);
        SqlDataAdapter myda = new SqlDataAdapter(sqlstr, sqlcon);
        DataSet myds = new DataSet();
        sqlcon.Open();
        myda.Fill(myds, "company_base");
        GridView1.DataSource = myds;
        GridView1.DataKeyNames = new string[] { "NcId" };//主键
        GridView1.DataBind();
        sqlcon.Close();
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //如果是绑定数据行 
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate)
            {
                ((LinkButton)e.Row.Cells[6].Controls[0]).Attributes.Add("onclick", "javascript:return confirm('你确认要删除：\"" + e.Row.Cells[1].Text + "\"吗?')");
            }
        }
    }

    protected void btnOut_Click(object sender, EventArgs e)
    {

        String sql = "select comid 公司编号,CompanyName 用户名,cperson 联系人,cphone 手机号码,email 电子邮件,Address 地址 from company_base order by Ncid asc ";
        ExcelObj.DataTable2Excel(this.Page.Response, DB.GetDataSet(sql).Tables[0], "company_base.xls");


    }

    private void loadData()
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();
        string strSql = "select * from company_base";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
        DataSet ds = new DataSet();
        adapt.Fill(ds, "company_base");
        this.GridView1.DataSource = ds.Tables["company_base"];
        this.GridView1.DataKeyNames = new string[] { "UserName" };
        GridView1.DataBind();
    }


    protected void btnSearch_Click(object sender, EventArgs e)
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();

        string strqq = txtParamName.Text.Trim();
        string strSql = "select * from company_base where UserName='" + strqq + "'";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);

        DataSet ds = new DataSet();
        adapt.Fill(ds, "company_base");

        this.GridView1.DataSource = ds.Tables["company_base"];
        GridView1.DataBind();
    }
}
