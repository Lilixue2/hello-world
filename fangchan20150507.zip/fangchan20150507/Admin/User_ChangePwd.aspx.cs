using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_User_ChangePwd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] == null)
        {
            Response.Write("<script>window.top.navigate('Default.aspx');</script>");
            return;
        }
        if (!IsPostBack)
        {
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            ArrayList paramList = new ArrayList();
            String adminid = Session["adminid"].ToString();

            String sql = String.Format("SELECT password FROM admin_base WHERE adminid=@0");
            DataTable user = DB.GetDataSet(sql, adminid).Tables[0];
            if (user.Rows.Count > 0)
            {
                if (user.Rows[0]["password"].ToString() == Common.Md5(txtOldUserPwd.Text))
                {
                    sql = String.Format("UPDATE admin_base SET password=@0 WHERE adminid=@1");

                    paramList.Clear();
                    paramList.Add(Common.Md5(txtUserPwd.Text));
                    paramList.Add(adminid);

                    DB.ExecuteSQL(sql, paramList);

                    txtOldUserPwd.Text = "";
                    txtUserPwd.Text = "";
                    txtConfirmUserPwd.Text = "";
                    lblTips.Text = "��������ɹ�";


                }
                else
                {
                    lblTips.Text = "ԭ�������!";
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            Response.End();
        }
    }
}
