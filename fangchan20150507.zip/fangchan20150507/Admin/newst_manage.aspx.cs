﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_newst_manage : System.Web.UI.Page
{
    private Bill bl = new Bill();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!base.IsPostBack)
        {
            this.bind();
        }

    }

    private void bind()
    {
        this.datalist1.DataSource = this.bl.GetNewT();
        this.datalist1.DataBind();
    }

    protected void datalist1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        String ncid = ((Label)datalist1.Rows[e.RowIndex].FindControl("lblPerId")).Text;
        DeleteItem(ncid);
    }

    private void DeleteItem(String ncid)
    {
        try
        {
            String sql = "DELETE FROM news_type WHERE TypeId=@0";
            DB.ExecuteSQL(sql, ncid);
            this.bind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            Response.End();
        }
    }



}
