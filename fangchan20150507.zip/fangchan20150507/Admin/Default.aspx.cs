﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Request.QueryString["mode"]) == "1")
            lblTips.Text = "用户名/密码错误！";
    }

    private bool checkRndCode()
    { 
        bool ret = false;
        String code = Convert.ToString(Session["rndcode"]);
        if (code.Equals(txtRndCode.Text))
            ret = true;
        else
            lblTips.Text = "验证码错误！";

        return ret;
    }


    protected void btnLogin_Click(object sender, ImageClickEventArgs e)
    {
        if (checkRndCode())
            Server.Transfer("~/login.aspx");
    }

    protected void btnReturn_Click(object sender, ImageClickEventArgs e)
    {
        if (Session["region"] != null && Session["region"].ToString().Equals("五华"))
            Response.Redirect("../wh/Default.aspx");
        else
            Response.Redirect("../index.aspx");
    }
}
