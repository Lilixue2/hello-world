﻿using System;
/// <summary>
/// Search_Condition 的摘要说明
/// </summary>
public class Condition
{
    private String jobClass = String.Empty;
    private String jobClassValue = String.Empty;
    private String degree = String.Empty;
    private int workType = 0;
    private String workYears = String.Empty;
    private String salary = String.Empty;
    private String companyType = String.Empty;
    private int publishDate = 0;
    private String keyword = String.Empty;

    public String Keyword
    {
        get
        {
            return keyword;
        }
        set 
        {
            keyword = value;
        }
    }

    public String JobClass
    {
        get
        {
            return jobClass;
        }
        set
        {
            jobClass = value;
        }
    }

    public String JobClassValue
    {
        get
        {
            return jobClassValue;
        }
        set
        {
            jobClassValue = value;
        }
    }

    public String Degree
    {
        get
        {
            return degree;
        }
        set
        {
            degree = value;
        }
    }

    public int WorkType
    {
        get
        {
            return workType;
        }
        set
        {
            workType = value;
        }
    }

    public String WorkYears
    {
        get
        {
            return workYears;
        }
        set
        {
            workYears = value;
        }
    }

    public String Salary
    {
        get
        {
            return salary;
        }
        set
        {
            salary = value;
        }
    }

    public String CompanyType
    {
        get
        {
            return companyType;
        }
        set
        {
            companyType = value;
        }
    }

    public int PublishDate
    {
        get
        {
            return publishDate;
        }
        set
        {
            publishDate = value;
        }
    }
}

public class comCondition
{
    private String jobClass = String.Empty;
    private String jobClassValue = String.Empty;
    private String jobArea = String.Empty;
    private String jobAreaValue = String.Empty; 
    private String education = String.Empty;
    private int sex = 0;
    private String lastUpdateDate = String.Empty;

    public String JobClass
    {
        get { return jobClass; }
        set { jobClass = value; }
    }

    public String JobClassValue
    {
        get { return jobClassValue; }
        set { jobClassValue = value; }
    }

    public String JobArea
    {
        get { return jobArea; }
        set { jobArea = value; }
    }

    public String JobAreaValue
    {
        get { return jobAreaValue; }
        set { jobAreaValue = value; }
    }

    public String Education
    {
        get { return education; }
        set { education = value; }
    }

    public int Sex
    {
        get { return sex; }
        set { sex = value; }
    }

    public String LastUpdateDate
    {
        get { return lastUpdateDate; }
        set { lastUpdateDate = value; }
    }
}