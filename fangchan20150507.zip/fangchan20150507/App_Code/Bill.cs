﻿using DBUtility;
using System;
using System.Data;
using System.Data.OleDb;
using System.Text;

/// <summary>
///bill 的摘要说明
/// </summary>
public class Bill
{

    private BaseSystem bs = new BaseSystem();

    public DataTable Getbm()
    {
        return SqlHelper.ExecuteDt("SELECT  NewsID, Title, Author, AddDate FROM news_info left join News_Type on News_Type.TypeID = news_info.TypeID " +
                   "WHERE IsActive = 1 AND IsVerified = 1 AND News_Type.TYPEid=2 ORDER BY news_info.newsid DESC");
    }

    public DataTable GetNew()
    {
        return SqlHelper.ExecuteDt("SELECT  * FROM news_type where parentid=1  ORDER BY typeid ASC");
    }

    public DataTable GetNewL()
    {
        return SqlHelper.ExecuteDt("SELECT  * FROM news_type where typeid=9  ORDER BY typeid ASC");
    }

    public DataTable GetNewW()
    {
        return SqlHelper.ExecuteDt("SELECT  * FROM news_type where typeid=4  ORDER BY typeid ASC");
    }

    public DataTable GetNewT()
    {
        return SqlHelper.ExecuteDt("SELECT  * FROM news_type  ORDER BY ordernum ASC");
    }

    public bool Addbm(string type, string name, string email, string company, string phone, string contents)
    {
        StringBuilder builder = new StringBuilder();
        builder.Append("insert into [bm]([type],[name],[email],[company],[phone],[contents])");
        builder.Append(string.Concat(new object[] { "values( '", type, "','", name, "','", email, "','", company, "','", phone, "','", contents, "')" }));
        return SqlHelper.ExecuteSql(builder.ToString());
    }


   
    public DataTable Getlm()
    {
        return SqlHelper.ExecuteDt("SELECT * from bm order by id asc ");
                  
    }

    public DataTable Getlm(string name)
    {
        return SqlHelper.ExecuteDt("SELECT * from bm  where type like '%" + name + "%' or name like  '%" + name + "%' or email like  '%" + name + "%' or company like  '%" + name + "%' or phone like  '%" + name + "%' or contents like  '%" + name + "%' order by id asc ");

    }


}
