﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ts_Register1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            String path = Request.PhysicalApplicationPath;
            path = System.IO.Path.GetDirectoryName(path) + "\\" + ConfigurationManager.AppSettings["Agreement"].ToString();
            txtAgreement.Text = Common.ReadFile(path);
        }
    }

    protected void Check(object sender, EventArgs e)
    {
        if (this.CheckBox1.Checked)
        {
            this.CheckBox1.Enabled = true;
        }
        else
        {
            this.CheckBox1.Enabled = false;
        }


    }


    protected void btnOk_Click(object sender, EventArgs e)
    {
        String comId = generateId();
        Session["comid"] = comId;
        if (IsValid == true)
        {
            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection strcon = new SqlConnection(myconn);
            strcon.Open();
            SqlCommand scd1 = new SqlCommand("insert into company_base(ComID,UserName,Password,CompanyName,License,Workers,Website,cperson,cphone,Email,Address) values('" + comId + "','" + txtUserName.Text + "','" + Common.Md5(Userpwd.Text) + "', '" + txtCompanyName.Text + "','" + txtLicense.Text + "','" + cmbWorkers.Text + "','" + txtWebsite.Text + "','" + cperson.Text + "','" + cphone.Text + "','" + txtEmail.Text + "','" + txtAddress.Text + "')", strcon);
            scd1.ExecuteNonQuery();
            strcon.Close();
            Response.Write("<script lanuage=javascript>alert('恭喜！企业注册成功！');location='index.aspx'</script>");
            Session["perid"] = null;
            Session["username"] = null;
        }
    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection strcon = new SqlConnection(myconn);
        strcon.Open();
        string Username = this.txtUserName.Text.ToString();
        SqlCommand cmd = new SqlCommand("select count(*) from company_base where UserName='" + txtUserName.Text + "'", strcon);
        int count = Convert.ToInt32(cmd.ExecuteScalar());
        if (count > 0)
        {
            args.IsValid = false;
        }
        else
        {
            args.IsValid = true;
        }
    }

    private string generateId()
    {
        long i = 1;
        foreach (byte b in Guid.NewGuid().ToByteArray())
        {
            i *= ((int)b + 1);
        }
        return string.Format("{0:x}", i - DateTime.Now.Ticks);
    }
}
