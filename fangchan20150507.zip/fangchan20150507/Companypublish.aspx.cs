﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ts_Companypublish : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox4.Text = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString();
        if (!IsPostBack)
        {
            Bind();
            if (Session["comid"] != null)
            {
            }
            else
            {
                Response.Write("<script>alert('请登录再查找信息，谢谢！');location.href = 'index.aspx';</script>");
                return;
            }
        }
    }
    private void Bind()//初始化
    {
        SqlConnection sqlcon = new SqlConnection("server=.;database=TFang;uid=sa;pwd=sa;");
        sqlcon.Open();

        //先初始化区域

        SqlCommand sqlcmdpro = new SqlCommand("select * from quyu", sqlcon);
        SqlDataReader sdrpro = sqlcmdpro.ExecuteReader();
        this.ddlQuyu.DataSource = sdrpro;
        this.ddlQuyu.DataTextField = "p_name";//显示的值
        this.ddlQuyu.DataValueField = "p_name";//主键
        this.ddlQuyu.DataBind();
        sdrpro.Close();
        sqlcon.Close();
    }
   
    protected void btnOk_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            string filename = FileUpload1.FileName.ToString();
            if (filename.Contains("jpg") || filename.Contains("png"))
            {
                FileUpload1.SaveAs(Server.MapPath("~/Image/House/" + TextBox4.Text + ".png"));//上传文件至某一路径下
                String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
                SqlConnection myConnection = new SqlConnection(myconn);
                myConnection.Open();
                string stradd = "insert into house(username,Hcontact,Hphone,ISBN,Htype,Hname,Hquyu,Haddress,Hshi,Hting,Hwei,Harea,Hmoney,Hceng,Hceng2,Hchaoxiang,Hzhuangxiu,Hkaipan,Hwuyefei,Hwuyename,Hyushouxuke,Hwuyeaddress,Hjiaotong,Hxuexiao,Hyiyuan,Hyinhang,Htingche,Hjianjie) values('" + Session["username"] + "','" + txtContactPerson.Text + "','" + txtPhone.Text + "','" + TextBox4.Text + "','" + ddlType.Text + "','" + txtHouseName.Text + "','" + this.ddlQuyu.SelectedValue.ToString() + "','" + txtAddress.Text + "','" + txtShi.Text + "','" + txtTing.Text + "','" + txtWei.Text + "','" + txtArea.Text + "','" + txtMoney.Text + "','" + txtCeng.Text + "','" + txtCeng2.Text + "','" + ddlChaoxiang.Text + "','" + ddlZhuangxiu.Text + "','" + ddlKaipan.Text + "','" + txtWuyefei.Text + "','" + txtWuyename.Text + "','" + txtYushouxuke.Text + "','" + txtWuyeaddress.Text + "','" + txtJiaotong.Text + "','" + txtXuexiao.Text + "','" + txtYiyuan.Text + "','" + txtYinhang.Text + "','" + txtTingche.Text + "','" + txtJianjie.Text + "')";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = myConnection;
                cmd.CommandText = stradd;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                myConnection.Close();
                Common.Alert("发布成功!", this);
            }
            else
            { Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "r", "alert(\" 请上传jpg，png格式的商品图片！\")", true); }
            }
        else
        { Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "s", "alert(\"请上传商品图片！\")", true); }
    }
}
