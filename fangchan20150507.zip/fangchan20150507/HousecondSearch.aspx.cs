﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class HousecondSearch : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["perid"] != null) 
            {
            }
            else
            {
                Response.Write("<script>alert('请登录再查找信息，谢谢！');location.href = 'index.aspx';</script>");
            }
        }
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();
        string strSql = "select * from housecond ";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
        DataSet ds = new DataSet();
        adapt.Fill(ds, "housecond");
        this.Gv1.DataSource = ds.Tables["housecond"];
        this.Gv1.DataKeyNames = new string[] { "ddlzone" };
        Gv1.DataBind();

    }

    protected void Houname_Click(object sender, EventArgs e)
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();

        string strqq = txthousename.Text.Trim();
        string strSql = "select * from housecond where txthousename='" + strqq + "'";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);

        DataSet ds = new DataSet();
        adapt.Fill(ds, "housecond");

        this.Gv1.DataSource = ds.Tables["housecond"];
        Gv1.DataBind();
    }

    protected void Houquyu_Click(object sender, EventArgs e)
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();

        string strqq = ddlzone.Text.Trim();
        string strSql = "select * from housecond where ddlzone='" + strqq + "'";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);

        DataSet ds = new DataSet();
        adapt.Fill(ds, "housecond");
        this.Gv1.DataSource = ds.Tables["housecond"];
        Gv1.DataBind();
    }
}


