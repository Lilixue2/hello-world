﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class ts_index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            LoadData();
            LoadData1();
            LoadData2();
            LoadData3();
            Label1.Text = "学校：唐山师范学院";
            Label7.Text = "专业：计算机科学与技术";
            Label8.Text = "指导老师：孟一真";
            Label9.Text = "联系人：薛莉莉";
            
        }
    }
    private void LoadData()
    {
        try
        {
            //0房产新闻
            String sql = "SELECT TOP 7 NewsID, Title, Author, AddDate FROM news_info " +
                   "WHERE IsActive = 1 AND IsVerified = 1 AND TypeID = 9 ORDER BY newsid DESC";

            //1房产资讯
            sql += ";SELECT TOP 7 NewsID, Title, Author, AddDate FROM news_info " +
                 "WHERE IsActive = 1 AND IsVerified = 1 AND TypeID = 3 or TypeID = 5 or TypeID = 6 or TypeID = 7 or TypeID = 8 ORDER BY newsid DESC";

            //2政策法规
            sql += ";SELECT TOP 7 NewsID, Title, Author, AddDate FROM news_info " +
                  "WHERE IsActive = 1 AND IsVerified = 1 AND TypeID = 4 ORDER BY newsid DESC";

            //3最新快讯
            sql += ";SELECT TOP 7 NewsID, Title, Author, AddDate FROM news_info " +
                 "WHERE IsActive = 1 AND IsVerified = 1 AND TypeID = 8 ORDER BY newsid DESC";

            DataSet dataset = DB.GetDataSet(sql);
            lstnews.DataSource = dataset.Tables[0].DefaultView;
            lstnews.DataBind();

            lstzixun.DataSource = dataset.Tables[1].DefaultView;
            lstzixun.DataBind();

            listflfg.DataSource = dataset.Tables[2].DefaultView;
            listflfg.DataBind();

            DataList4.DataSource = dataset.Tables[3].DefaultView;
            DataList4.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            Response.End();
        }
    }
    private void LoadData1()
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();
        string strSql = "select  Top(4) * from house order by houseid desc ";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
        DataSet ds = new DataSet();
        adapt.Fill(ds, "house");
        this.DataList1.DataSource = ds.Tables["house"];
        DataList1.DataBind();
    }
    private void LoadData2()
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();
        string strSql = "select  Top(4) * from housecond order by housecondid desc ";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
        DataSet ds = new DataSet();
        adapt.Fill(ds, "housecond");
        this.DataList2.DataSource = ds.Tables["housecond"];
        DataList2.DataBind();
    }
    private void LoadData3()
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();
        string strSql = "select  Top(4) * from house where Htype='商铺' order by houseid desc ";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
        DataSet ds = new DataSet();
        adapt.Fill(ds, "house");
        this.DataList3.DataSource = ds.Tables["house"];
        DataList3.DataBind();
    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        string houseid = ((Label)e.Item.FindControl("Label2")).Text;

        if (e.CommandName == "ImageButton")
        {
            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn);
            myConnection.Open();
            string strsql = "select * from house where houseid='" + houseid + "'";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = myConnection;
            cmd.CommandText = strsql;
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            myConnection.Close();
            Response.Redirect(string.Format("~/Housenew_view.aspx?houseid={0}", houseid));

        }
    }
    protected void DataList2_ItemCommand(object source, DataListCommandEventArgs e)
    {
        string housecondid = ((Label)e.Item.FindControl("Label3")).Text;

        if (e.CommandName == "ImageButton")
        {
            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn);
            myConnection.Open();
            string strsql = "select * from housecond where housecondid='" + housecondid + "'";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = myConnection;
            cmd.CommandText = strsql;
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            myConnection.Close();
            Response.Redirect(string.Format("~/Housecond_view.aspx?housecondid={0}", housecondid));

        }
    }
    protected void DataList3_ItemCommand(object source, DataListCommandEventArgs e)
    {
        string houseid = ((Label)e.Item.FindControl("Label5")).Text;

        if (e.CommandName == "ImageButton")
        {
            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn);
            myConnection.Open();
            string strsql = "select * from house where houseid='" + houseid + "'";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = myConnection;
            cmd.CommandText = strsql;
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            myConnection.Close();
            Response.Redirect(string.Format("~/Housenew_view.aspx?houseid={0}", houseid));

        }
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Server.Transfer("login.aspx");
    }

    protected string Left(object s, int length)
    {
        try
        {
            string ret;

            if (s.ToString().Trim() == "")
                return "---";
            if (s.ToString().Length > length)
            {
                ret = s.ToString();
                ret = ret.Substring(0, length) + "...";
            }
            else
            {
                return s.ToString();
            }
            return ret;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void lnkbtn_Logout_Click(object sender, EventArgs e)
    {
        Session.Clear();
    }
    protected void lnkbtn_LogoutCompany_Click(object sender, EventArgs e)
    {
        Session.Clear();
    }
}
