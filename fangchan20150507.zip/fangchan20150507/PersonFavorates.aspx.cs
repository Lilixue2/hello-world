﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class PersonFavorates : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (Session["perid"] == null)
        {
            Response.Redirect("~/index.aspx");
        }
        if (!IsPostBack)
        {
            myDataBind();
            myDataBind1();
        }
    }
     private void myDataBind()
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();
        string strSql = "SELECT  house.houseid As houseid, favorites.Id,   favorites.AddDate,  house.Hname, house.ISBN FROM      favorites INNER JOIN house ON  favorites.houseid = house.houseid  order by AddDate desc ";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
        DataSet ds = new DataSet();
        adapt.Fill(ds, "favorites");
        this.DataList1.DataSource = ds.Tables["favorites"];
        DataList1.DataBind();

    }
    private void myDataBind1()
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();
        string strSql = "SELECT housecond.housecondid As housecondid, favoritesecond.Id,favoritesecond.AddDate,  housecond.txthousename, housecond.ISBN FROM      favoritesecond INNER JOIN housecond ON  favoritesecond.housecondid = housecond.housecondid  order by AddDate desc ";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
        DataSet ds = new DataSet();
        adapt.Fill(ds, "favoritesecond");
        this.DataList2.DataSource = ds.Tables["favoritesecond"];
        DataList2.DataBind();

    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        string faid = ((Label)e.Item.FindControl("Label1")).Text;
        string houseid = ((Label)e.Item.FindControl("Label3")).Text;
        
        if (e.CommandName == "Delete1")
        {
            String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn);
            myConnection.Open();
            string strSql ="Delete favorites  where houseid=" + faid;
            SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
            DataSet ds = new DataSet();
            adapt.Fill(ds, "favorites");
            this.DataList1.DataSource = ds.Tables["favorites"];
            DataList1.DataBind();
            myConnection.Close();
        }


        if (e.CommandName == "Image1" || e.CommandName == "Links1")
        {
            Response.Redirect(string.Format("~/Housenew_view.aspx?houseid={0}", houseid));
        }


    }
   

   

    protected void Button1_Click(object sender, EventArgs e)
    {

    }


     protected void DataList2_ItemCommand(object source, DataListCommandEventArgs e)
    {
        string fasecondid = ((Label)e.Item.FindControl("Label4")).Text;
        string housecondid = ((Label)e.Item.FindControl("Label6")).Text;
        
        if (e.CommandName == "Delete2")
        {
            String myconn1 = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
            SqlConnection myConnection = new SqlConnection(myconn1);
            myConnection.Open();
            string strSql1 = "Delete favoritesecond  where housecondid=" + fasecondid;
            SqlDataAdapter adapt = new SqlDataAdapter(strSql1, myConnection);
            DataSet ds = new DataSet();
            adapt.Fill(ds, "favoritesecond");
            this.DataList2.DataSource = ds.Tables["favoritesecond"];
            DataList2.DataBind();
        }


        if (e.CommandName == "Image2" || e.CommandName == "Links2")
        {
            Response.Redirect(string.Format("~/Housecond_view.aspx?housecondid={0}", housecondid));
        }


    }

   

    protected void Button2_Click(object sender, EventArgs e)
    {
        
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = true;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        Panel2.Visible =false;
    }

}