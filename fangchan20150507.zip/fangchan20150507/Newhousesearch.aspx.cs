﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class newhousesearch : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
            if (Session["perid"] != null)
            {
                BindData();
            }
            else
            {
                Response.Write("<script>alert('请登录再查找信息，谢谢！');location.href = 'index.aspx';</script>");
            }
        }
    }

    protected void BindData()
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();
        string strSql = "select * from house ";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);
        DataSet ds = new DataSet();
        adapt.Fill(ds, "house");


        DataTable dt = new DataTable();
        dt.Columns.Add("ID");
        dt.Columns.Add("Name");
        for (int i = 0; i < 10; i++)
        {
            dt.Rows.Add(i.ToString(), i.ToString());
        }
        this.Gv1.DataSource = ds.Tables["house"];
        this.Gv1.DataKeyNames = new string[] { "Hquyu" };
        Gv1.DataBind();
    }
    protected void Houname_Click(object sender, EventArgs e)
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();

        string strqq = Hname.Text.Trim();
        string strSql = "select * from house where Hname='" + strqq + "'";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);

        DataSet ds = new DataSet();
        adapt.Fill(ds, "house");

        this.Gv1.DataSource = ds.Tables["house"];
        Gv1.DataBind();

    }
    protected void Houquyu_Click(object sender, EventArgs e)
    {
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection myConnection = new SqlConnection(myconn);
        myConnection.Open();

        string strqq = Hquyu.Text.Trim();
        string strSql = "select * from house where Hquyu='" + strqq + "'";
        SqlDataAdapter adapt = new SqlDataAdapter(strSql, myConnection);

        DataSet ds = new DataSet();
        adapt.Fill(ds, "house");
        this.Gv1.DataSource = ds.Tables["house"];
        Gv1.DataBind();
    }
 
        
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.Gv1.PageIndex = e.NewPageIndex;
            BindData();
        }
    }


