﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Web.Profile;

public partial class ts_logo : System.Web.UI.Page
{
    private BaseSystem bs = new BaseSystem();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["comid"] != null)
            {
                InitInformation();
                txtComId.Value = Session["comid"].ToString();
                loadImage();
                string lblName = Session["comid"].ToString();
            }
            else
                Response.Write("<script>alert('请登录再查找信息，谢谢！');location.href = 'index.aspx';</script>");
        }
    }

    private void InitInformation()
    {
        String comid = Session["comid"].ToString();
        String sql = String.Empty;
        sql = "SELECT username,companyname FROM company_base WHERE comid=@0;";
    }

   

    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {

            if (this.Update.PostedFile.ContentLength < 0x989680)
            {
                if (this.Update.HasFile)
                {
                    string contentType = this.Update.PostedFile.ContentType;
                    FileInfo info = new FileInfo(this.Update.PostedFile.FileName);
                    string name = info.Name;
                    string path = base.Server.MapPath("image/uploadfile/" + name);
                    if (!File.Exists(path))
                    {
                        try
                        {
                            this.Update.SaveAs(path);
                        }
                        catch (Exception exception)
                        {
                            this.Label1.Text = "提示：文件上传失败，失败原因：" + exception.Message;
                            this.Label2.Text = "";
                        }
                    }
                    else
                    {
                        this.Label1.Text = "提示：文件已经存在，请重命名后上传";
                        this.Label2.Text = "";
                    }
                    this.Label2.Text = "<a href=" + path + ">" + name + "</a>";
                    this.Session["webFilePath"] = path;
                    this.Session["Path"] = info.Name;
                    String sql = "UPDATE company_base SET logo=@0 WHERE comid=@1";
                    object[] parameters = new object[] { name, txtComId.Value };
                    DB.ExecuteSQL(sql, parameters);
                    loadImage();
                }
            }
            else
            {
                base.Response.Write(this.bs.ShowWindow("软件不允许超过10M"));
            }
        }
        catch
        {
            base.Response.Write(this.bs.ShowWindow("序列号只能为数字"));
        }
    }

    private bool loadImage()
    {
        bool ret = false;
        String sql = "SELECT logo FROM company_base WHERE comid=@0";
        DataTable logo = DB.GetDataSet(sql, txtComId.Value).Tables[0];

        if (logo.Rows.Count > 0)
        {
            string url = Convert.ToString(logo.Rows[0]["logo"]);

            string path = "image/uploadfile/";
            string picUrl = path + url;
            if (picUrl != "")
            {
                Image1.ImageUrl = picUrl;
                ret = true;
            }
        }
        return ret;
    }


    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        if (this.bs.DelImg(this.Session["webFilePath"].ToString()))
        {
            base.Response.Write(this.bs.ShowWindow("成功", "logo.aspx"));
        }
        else
        {
            base.Response.Write(this.bs.ShowWindow("出错"));
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            String sql = "UPDATE company_base SET logo='' WHERE comid=@0";
            DB.ExecuteSQL(sql,txtComId.Value);
            Image1.ImageUrl = "~/Images/Company.gif";
            Label1.Text = "图片标识已删除";
        }
        catch (Exception ex)
        {
            Label1.Text = ex.Message;
        }
    }
}
