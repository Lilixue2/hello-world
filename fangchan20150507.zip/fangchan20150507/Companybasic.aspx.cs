﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class ts_Companybasic : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["comid"] != null)
            {
                loadBaseInfo();
            }
            else
            {
                Response.Write("<script>alert('请登录再查找信息，谢谢！');location.href = 'index.aspx';</script>");
                return;
            }
        }
    }


  

    protected void btnOk_Click(object sender, EventArgs e)
    {
        
        String myconn = "Server=localhost;DataBase=TFang;Integrated Security=SSPI";
        SqlConnection strcon = new SqlConnection(myconn);
        strcon.Open();
        string stradd = "update company_base set Workers='" + cmbWorkers.Text + "',Website= '" + txtWebsite.Text + "',Email='" + txtEmail2.Text + "',Address='" + txtAddress.Text + "' where username = '" + Session["username"] + "'";
        SqlCommand mycmd = new SqlCommand();
        mycmd.Connection = strcon;
        mycmd.CommandText = stradd;
        mycmd.CommandType = CommandType.Text;
        mycmd.ExecuteNonQuery();
        strcon.Close();
        Common.Alert("保存数据成功!", this);
        loadBaseInfo();
    }

    private void loadBaseInfo()
    {
        String comid = Session["comid"].ToString();
        txtComId.Value = comid;
        String sql = "SELECT * FROM company_base WHERE comid = @0 ";
        DataTable company = DB.GetDataSet(sql,comid).Tables[0];
        if (company.Rows.Count > 0)
        {
            DataRow row = company.Rows[0];
            lblCompany.Text = Convert.ToString(row["companyname"]);
            lblLicense.Text = Convert.ToString(row["license"]);
            cmbWorkers.SelectedValue = Convert.ToString(row["workers"]);
            txtEmail2.Text = Convert.ToString(row["email"]);
            txtWebsite.Text = Convert.ToString(row["website"]);
            txtAddress.Text = Convert.ToString(row["address"]);
        }
    }
}
