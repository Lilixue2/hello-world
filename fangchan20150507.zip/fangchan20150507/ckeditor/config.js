﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
{
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
    // config.uiColor = '#AADC6E';
     // Define changes to default configuration here. For example:
    //配置默认配置 
    config.language = 'zh-cn'; //配置语言 
     config.uiColor = '#FFF'; //背景颜色 
    // config.width = 400; //宽度 
 //    config.height = 400; //高度 
     config.skin = 'v2'; //编辑器皮肤样式 
     //取消 “拖拽以改变尺寸”功能 
     config.resize_enabled = false; 
    // 使用基础工具栏 
 //    config.toolbar = "Basic"; 
  //   使用全能工具栏 
 //   config.toolbar = "Full";
     config.scayt_autoStartup = false
     config.language = 'zh-cn'; //中文
     config.filebrowserBrowseUrl = '../ckfinder/ckfinder.html';
     config.filebrowserImageBrowseUrl = '../ckfinder/ckfinder.html?Type=Images';
     config.filebrowserFlashBrowseUrl = '../ckfinder/ckfinder.html?Type=Flash';
     config.filebrowserUploadUrl = '../ckfinder/core/connector/aspx/connector.aspx?command=QuickUpload&type=Files';
     config.filebrowserImageUploadUrl = '../ckfinder/core/connector/aspx/connector.aspx?command=QuickUpload&type=Images';
     config.filebrowserFlashUploadUrl = '../ckfinder/core/connector/aspx/connector.aspx?command=QuickUpload&type=Flash';
};
