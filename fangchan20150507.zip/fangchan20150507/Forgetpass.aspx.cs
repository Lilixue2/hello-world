﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class Include_forgetpass : System.Web.UI.Page
{
   

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            this.Button1.Attributes.Add("onclick", "javascript:return checkAll();");
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //*防止SQL注入
        //if (!DB.CheckParams(new object[] { this.TextBox1.Text, this.TextBox3.Text }))
        //{
        //    Response.Redirect("ErrorSQLZR.aspx");
        //    return;
        //}

   
        String sql = "SELECT * FROM personal_base WHERE username = @0 and question=@1 and answer=@2";
        object[] parameters = new object[]{this.TextBox1.Text, txtQuestion.SelectedValue, this.TextBox3.Text};

        DataTable company = DB.GetDataSet(sql, parameters).Tables[0];
        if (company.Rows.Count > 0)
        {
            DataRow row = company.Rows[0];
            Common.Alert("您的密码是"+row["pwd"], this);
        }
        else
        {
            Common.Alert("您输入的帐号，或回答的问题不对!", this);
        }
         
    }
   

}

